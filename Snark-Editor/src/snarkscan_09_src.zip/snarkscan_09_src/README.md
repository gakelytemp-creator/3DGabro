# SnarkScan_09 — sources, tests, results

`SnarkScan_09.html` = `SnarkScan_08.html` + `correct09.js` + the 31 exact replacements in `build09.py`.
`SnarkScan_08.html` is only read. The recognition of 08 is not changed.

## Build

    sh build.sh /path/to/SnarkScan_08.html      # writes SnarkScan_09.html, checks the script for syntax

## What is where

| file | what it is |
|---|---|
| `correct09.js` | everything new: state (measured copy, numbers of elements, quantisation flags), geometry of the profile, the commands, the pick with Shift, the section with the flat manipulator, the boxes with numbers, the wheel, the experience file. Its head comment is the map. |
| `build09.py` | the replacements in the text of 08, each asserted to be found exactly once |
| `tests/baseline.cjs` | runs a page on a scan and records what it recognises (used for the baseline of 08) |
| `tests/test09.cjs` | 61 checks of 09 on a scan, PASS / FAIL |
| `tests/legacy.cjs` | the tools of 08 pressed in 08 and in 09, the profiles compared |
| `results/` | the baseline of 08 on 07.obj, the test output, two screenshots |

## Tests (Chrome through Playwright, three.js 0.180.0 from node_modules)

    node tests/baseline.cjs SnarkScan_08.html 07.obj baseline.json
    node tests/test09.cjs SnarkScan_09.html 07.obj baseline.json outdir
    node tests/legacy.cjs 07.obj SnarkScan_08.html SnarkScan_09.html outdir

Run of 22 November 2026 on 07.obj: test09 61 passed, 0 failed (third build of 09: larger manipulator, Redo, boxes that can be dragged, larger corner marks, edges at the ends of the body can be picked). legacy 4 of 4 equal to the last digit, run on the first build of 09.
