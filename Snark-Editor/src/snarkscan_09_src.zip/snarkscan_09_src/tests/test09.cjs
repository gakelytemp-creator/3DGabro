// Tests of SnarkScan_09 on a scan: the baseline of 08 is kept, every command does what the specification says.
// usage: node test09.cjs <SnarkScan_09.html> <scan.obj> <baseline.json> <outdir>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const [pageFile, scan, baseFile, outDir] = process.argv.slice(2);
const THREE_DIR = path.join(__dirname, 'node_modules/three');
const base = JSON.parse(fs.readFileSync(baseFile, 'utf8'));
let pass = 0, fail = 0; const rows = [];
const ok = (name, cond, detail = '') => { cond ? pass++ : fail++; rows.push(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); console.log(rows[rows.length - 1]); };
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--js-flags=--max-old-space-size=8192'] });
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const errors = []; page.on('pageerror', e => errors.push(String(e))); page.on('dialog', d => { errors.push('dialog: ' + d.message()); d.dismiss(); });
  await page.route('https://cdn.jsdelivr.net/npm/three@0.180.0/**', r => { const f = path.join(THREE_DIR, r.request().url().split('three@0.180.0/')[1]); fs.existsSync(f) ? r.fulfill({ body: fs.readFileSync(f), contentType: 'text/javascript' }) : r.abort(); });
  await page.goto('file://' + path.resolve(pageFile));
  await page.waitForFunction(() => window.__scan && window.__scanFn && window.__c9, null, { timeout: 60000 });
  await page.setInputFiles('#fileScan', scan);
  await page.waitForFunction(() => window.__scan.n > 0 && !document.body.classList.contains('busy'), null, { timeout: 420000, polling: 500 });
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="orient"]').click());
  await page.waitForFunction(() => window.__scan.frame, null, { timeout: 420000, polling: 500 });
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="recognise"]').click());
  await page.waitForFunction(() => window.__scan.rec, null, { timeout: 480000, polling: 500 });
  await page.waitForTimeout(1500);

  // 1. the baseline of 08
  const ents = await page.evaluate(() => __scan.rec.extr.ents.map(e => ({ t: e.t, p0: e.p0, p1: e.p1, c: e.c || null, r: e.r || null, guess: !!e.guess, id: e.id })));
  let worst = 0; const B = base.extr.ents; if (B.length === ents.length) ents.forEach((e, i) => { for (const k of ['p0', 'p1']) for (let q = 0; q < 2; q++) worst = Math.max(worst, Math.abs(e[k][q] - B[i][k][q])); if (e.t !== 'line') worst = Math.max(worst, Math.abs(e.r - B[i].r)); });
  ok('baseline: the same number of elements as 08', ents.length === B.length, `${ents.length} / ${B.length}`);
  ok('baseline: every element where 08 put it', B.length === ents.length && worst < 1e-4 && ents.every((e, i) => e.t === B[i].t && e.guess === B[i].guess), `largest difference ${worst.toExponential(2)} mm`);
  ok('state: every element has its own number', new Set(ents.map(e => e.id)).size === ents.length && ents.every(e => e.id > 0));
  ok('state: the measured copy is there', await page.evaluate(() => { const X = __scan.rec.extr; return Array.isArray(X.meas) && X.meas.length === X.ents.length; }));

  // helpers in the page
  await page.evaluate(() => {
    window.T = {
      X: () => __scan.rec.extr,
      snap: () => JSON.stringify(__scan.rec.extr.ents.map(e => ({ t: e.t, p0: e.p0, p1: e.p1, c: e.c, r: e.r }))),
      corners: () => { const X = __scan.rec.extr; return X.corners.map(c => ({ i: c.i, j: c.j, gap: c.gap, kinds: [X.ents[c.i].t, X.ents[c.j].t], guess: [!!X.ents[c.i].guess, !!X.ents[c.j].guess], st: __c9.corner(c.i) })); },
      dir: e => { const l = Math.hypot(e.p1[0] - e.p0[0], e.p1[1] - e.p0[1]); return [(e.p1[0] - e.p0[0]) / l, (e.p1[1] - e.p0[1]) / l]; },
      onLine: (p, e) => { const d = T.dir(e); return Math.abs((p[0] - e.p0[0]) * d[1] - (p[1] - e.p0[1]) * d[0]); }
    };
  });
  const corners = await page.evaluate(() => T.corners());
  const n = ents.length, lineAt = i => ents[(i + n) % n].t === 'line', lenOf = i => { const e = ents[(i + n) % n]; return e.t === 'line' ? Math.hypot(e.p1[0] - e.p0[0], e.p1[1] - e.p0[1]) : 0; };
  // a corner of two flat faces whose far neighbours are flat too, and whose angle is not round
console.log('corners: ' + corners.map(c => `${c.i}:${c.kinds[0][0]}${c.kinds[1][0]} ${c.st.angle.toFixed(1)}° ${c.st.lenA.toFixed(2)}/${c.st.lenB.toFixed(2)}${c.guess[0] || c.guess[1] ? 'g' : ''}`).join(' | '));
  const room = c => Math.min(c.st.lenA, c.st.lenB, lenOf(c.i - 1), lenOf(c.j + 1));
  const cand = corners.filter(c => c.gap < 0.05 && c.kinds[0] === 'line' && c.kinds[1] === 'line' && lineAt(c.i - 1) && lineAt(c.j + 1) && Math.abs(c.st.angle - 90) < 6).sort((a, b) => room(b) - room(a));
  const cc = cand[0]; console.log('candidates: ' + cand.map(c => `${c.i} (room ${room(c).toFixed(2)})`).join(', '));
  ok('found a corner of flat faces to work on', !!cc, cc ? `edge ${cc.i}: ${cc.st.angle.toFixed(3)}°, lengths ${cc.st.lenA.toFixed(3)} / ${cc.st.lenB.toFixed(3)}` : '');
  const E = cc.i;

  // 2. the pick
  const sels = () => page.evaluate(() => __c9.state.sels.map(q => q.type + q.i).join(','));
  await page.evaluate(() => __c9.run('select', { type: 'face', i: 0 })); await page.evaluate(() => __c9.run('select', { type: 'face', i: 2, add: true }));
  ok('pick: Shift adds', await sels() === 'face0,face2', await sels());
  await page.evaluate(() => __c9.run('select', { type: 'face', i: 0 })); ok('pick: a click on a picked one lets it go', await sels() === 'face2', await sels());
  await page.evaluate(() => __c9.run('select', { type: 'edge', i: 5 })); ok('pick: a click without Shift on another replaces the pick', await sels() === 'edge5', await sels());
  await page.evaluate(() => { __c9.run('select', { type: 'face', i: 1, add: true }); __c9.run('select', { type: 'face', i: 3, add: true }); __c9.run('select', { type: 'face', i: 7 }); });
  ok('pick: many picked, a click without Shift on another leaves that one alone', await sels() === 'face7', await sels());
  await page.evaluate(() => __c9.run('select', {})); ok('pick: a click beside lets everything go', await sels() === '', await sels());

  // 3. the angle
  const r1 = await page.evaluate(E => { const X = T.X(), c = X.corners.find(q => q.i === E), A = X.ents[c.i], Bf = X.ents[c.j], nx = X.ents[(c.i - 1 + X.ents.length) % X.ents.length], P = [...A[c.ka]], dB = T.dir(Bf), dN = T.dir(nx), all = X.ents.map(e => e.t === 'line' ? T.dir(e) : null), before = T.snap(), undo = __scan.undo.length;
    const r = __c9.run('setAngle', { edge: E, side: 'a', angle: 90 }); const X2 = T.X(), c2 = X2.corners.find(q => q.i === E), A2 = X2.ents[c2.i], B2 = X2.ents[c2.j], nx2 = X2.ents[(c2.i - 1 + X2.ents.length) % X2.ents.length], far = A2[c2.ka === 'p0' ? 'p1' : 'p0'];
    let turned = 0; X2.ents.forEach((e, i) => { if (e.t === 'line' && all[i] && Math.abs(all[i][0] * T.dir(e)[1] - all[i][1] * T.dir(e)[0]) > 1e-9) turned++; });
    return { ok: r.ok, angle: __c9.corner(E).angle, pivot: Math.hypot(A2[c2.ka][0] - P[0], A2[c2.ka][1] - P[1]), other: Math.abs(dB[0] * T.dir(B2)[1] - dB[1] * T.dir(B2)[0]), farOnNext: T.onLine(far, { p0: nx.p0, p1: nx.p1 }), nextDir: Math.abs(dN[0] * T.dir(nx2)[1] - dN[1] * T.dir(nx2)[0]), turned, changed: before !== T.snap(), undo: __scan.undo.length - undo }; }, E);
  ok('angle: set to 90°', r1.ok && Math.abs(r1.angle - 90) < 1e-6, `${r1.angle}°`);
  ok('angle: the edge stays where it is', r1.pivot < 1e-9, `${r1.pivot.toExponential(1)} mm`);
  ok('angle: the other face stands still', r1.other < 1e-12);
  ok('angle: the new corner lies on the endless line of the next face', r1.farOnNext < 1e-6, `${r1.farOnNext.toExponential(1)} mm off it`);
  ok('angle: only the active face changed its direction', r1.turned === 1 && r1.nextDir < 1e-12, `${r1.turned} turned`);
  ok('angle: one step of Undo', r1.undo === 1);
  const u1 = await page.evaluate(B0 => { __c9.run('undo'); const X = T.X(); return X.ents.every((e, i) => Math.abs(e.p0[0] - B0[i].p0[0]) < 1e-9 && Math.abs(e.p1[1] - B0[i].p1[1]) < 1e-9); }, ents);
  ok('undo: the body is as it was', u1);
  const r2 = await page.evaluate(E => { const b = T.snap(), u = __scan.undo.length, r = __c9.run('setAngle', { edge: E, side: 'a', angle: 0 }); return { ok: r.ok, why: r.why, same: b === T.snap(), undo: __scan.undo.length - u, msg: __c9.state.msg }; }, E);
  ok('refusal: an impossible angle changes nothing and says why', !r2.ok && r2.same && r2.undo === 0 && !!r2.why, r2.why);

  // 4. the angle held to a grid
  const r3 = await page.evaluate(E => { const r = __c9.run('quantAngle', { edge: E, side: 'a', mode: '90' }), X = T.X(), A = X.ents[X.corners.find(q => q.i === E).i]; return { ok: r.ok, angle: __c9.corner(E).angle, flag: A.qa }; }, E);
  ok('quantise the angle: 90° switched on turns the face square and holds it', r3.ok && Math.abs(r3.angle - 90) < 1e-6 && r3.flag === '90', `${r3.angle}°, held to ${r3.flag}`);
  const r4 = await page.evaluate(E => { const r = __c9.run('setAngle', { edge: E, side: 'a', angle: 88.3 }), X = T.X(), A = X.ents[X.corners.find(q => q.i === E).i]; return { ok: r.ok, angle: __c9.corner(E).angle, flag: A.qa || null, drops: __c9.state.drops.length }; }, E);
  ok('typed number: 88.3 is taken as typed and switches the quantisation off', r4.ok && Math.abs(r4.angle - 88.3) < 1e-6 && r4.flag === null && r4.drops > 0, `${r4.angle}°, held to ${r4.flag}`);
  const r5 = await page.evaluate(E => { const r = __c9.run('quantAngle', { edge: E, side: 'a', mode: 'deg' }); return { ok: r.ok, angle: __c9.corner(E).angle }; }, E);
  ok('quantise the angle: whole degrees', r5.ok && Math.abs(r5.angle - Math.round(r5.angle)) < 1e-6, `${r5.angle}°`);
  await page.evaluate(E => { __c9.run('quantAngle', { edge: E, side: 'a', mode: '90' }); }, E);

  // 5. sizes
  const r6 = await page.evaluate(E => { const r = __c9.run('quantSize', { edge: E, side: 'b', on: true }), st = __c9.corner(E); return { ok: r.ok, why: r.why, len: st.lenB, held: st.sizeHeldTo[1], angle: st.angle, aHeld: st.angleHeldTo }; }, E);
  ok('quantise a size: the length lands on whole millimetres and is held', r6.ok && Math.abs(r6.len - Math.round(r6.len)) < 1e-6 && r6.held === 1, `${r6.len} mm` + (r6.why ? ' ' + r6.why : ''));
  ok('quantise a size: the angle at the edge is not disturbed', Math.abs(r6.angle - 90) < 1e-6 && r6.aHeld === '90', `${r6.angle}°`);
  const r7 = await page.evaluate(E => { const L = __c9.corner(E).lenB, r = __c9.run('setLength', { edge: E, side: 'b', length: Math.round(L) + 0.3 }), st = __c9.corner(E); return { ok: r.ok, len: st.lenB, want: Math.round(L) + 0.3, held: st.sizeHeldTo[1], angle: st.angle }; }, E);
  ok('typed number: a length off the grid is taken as typed and switches the quantisation off', r7.ok && Math.abs(r7.len - r7.want) < 1e-6 && r7.held === null, `${r7.len} mm, held to ${r7.held}`);
  const r8 = await page.evaluate(E => { const X = T.X(), c = X.corners.find(q => q.i === E), A = JSON.parse(JSON.stringify(X.ents[c.i])), dA = T.dir(A), before = __c9.corner(E), r = __c9.run('shift', { edge: E, side: 'a', by: 0.5 }), X2 = T.X(), c2 = X2.corners.find(q => q.i === E), A2 = X2.ents[c2.i], Bf = X2.ents[c2.j]; return { ok: r.ok, dir: Math.abs(dA[0] * T.dir(A2)[1] - dA[1] * T.dir(A2)[0]), moved: T.onLine(A2.p0, A), onOther: T.onLine(A2[c2.ka], Bf), angle: __c9.corner(E).angle, dLen: Math.abs(__c9.corner(E).lenB - before.lenB) }; }, E);
  ok('move: the face keeps its direction and goes 0.5 mm aside', r8.ok && r8.dir < 1e-12 && Math.abs(r8.moved - 0.5) < 1e-9, `${r8.moved} mm`);
  ok('move: the edge slides along the other face, the angle stays', r8.onOther < 1e-9 && Math.abs(r8.angle - 90) < 1e-6 && Math.abs(r8.dLen - 0.5) < 1e-6, `length of the other face changed by ${r8.dLen.toFixed(6)} mm`);
  // conflict: a size held, then the face is turned
  const r9 = await page.evaluate(E => { __c9.run('quantSize', { edge: E, side: 'a', on: true }); const h0 = __c9.corner(E).sizeHeldTo[0]; __c9.run('quantAngle', { edge: E, side: 'a', mode: 'off' }); __c9.run('setAngle', { edge: E, side: 'a', angle: 84.37 }); const st = __c9.corner(E); return { h0, h1: st.sizeHeldTo[0], len: st.lenA }; }, E);
  ok('conflict: turning a face whose length was held switches that hold off, in the open', r9.h0 === 1 && r9.h1 === null, `length now ${r9.len} mm`);

  // 6. a round neighbour: the whole circle is taken
    const arcC = corners.find(c => c.gap < 0.05 && c.kinds[0] === 'line' && c.kinds[1] === 'line' && !lineAt(c.i - 1) && c.st.lenA > 3 && c.st.lenB > 3);
  if (arcC) { const ra = await page.evaluate(E => { const X = T.X(), n = X.ents.length, arc = X.ents[(E - 1 + n) % n], c0 = [...arc.c], r0 = arc.r, a0 = __c9.corner(E).angle; let r = __c9.run('setAngle', { edge: E, side: 'a', angle: a0 + 0.8 }); if (!r.ok) r = __c9.run('setAngle', { edge: E, side: 'a', angle: a0 - 0.8 }); const X2 = T.X(), c2 = X2.corners.find(q => q.i === E), A2 = X2.ents[c2.i], far = A2[c2.ka === 'p0' ? 'p1' : 'p0'], arc2 = X2.ents[(E - 1 + n) % n]; return { ok: r.ok, why: r.why, onCircle: Math.abs(Math.hypot(far[0] - c0[0], far[1] - c0[1]) - r0), same: Math.hypot(arc2.c[0] - c0[0], arc2.c[1] - c0[1]) + Math.abs(arc2.r - r0), angle: __c9.corner(E).angle - a0 }; }, arcC.i);
    ok('round neighbour: the new corner lies on its whole circle, centre and radius untouched', ra.ok && ra.onCircle < 1e-9 && ra.same < 1e-12, ra.ok ? `${ra.onCircle.toExponential(1)} mm off the circle` : ra.why); await page.evaluate(() => __c9.run('undo')); }
  else ok('round neighbour: a corner with a round face next to it', false, 'none found in this scan');

  // 7. the section, the manipulator, the wheel
  await page.evaluate(E => __c9.run('openSection', { edge: E, at: 0.5, side: 'a' }), E); await page.waitForTimeout(400);
  const g0 = await page.evaluate(() => { const G = __c9.state.G, cv = document.getElementById('view'), r = cv.getBoundingClientRect(), THREE = __snark.THREE; if (!G || !G.parent) return null; const cam = __c9.cam; return { ov: getComputedStyle(document.getElementById('c9ov')).display, ang: document.getElementById('c9Ang').value, boxes: ['c9A', 'c9La', 'c9Lb'].map(id => { const b = document.getElementById(id).getBoundingClientRect(); return [b.left, b.top, b.width, b.height]; }), cv: [r.left, r.top, r.width, r.height] }; });
  ok('section: opened, with the boxes of the angle and of both lengths on the screen', !!g0 && g0.ov !== 'none' && g0.boxes.every(b => b[2] > 20 && b[3] > 10), g0 ? `angle box reads ${g0.ang}°` : 'no manipulator');
  await page.screenshot({ path: path.join(outDir, 'section.png') });
  const size = () => page.evaluate(() => __c9.pix());
  const s0 = await size();
  const cvBox = g0.cv, cx = cvBox[0] + cvBox[2] / 2, cy = cvBox[1] + cvBox[3] / 2;
  await page.mouse.move(cx, cy); for (let i = 0; i < 6; i++) { await page.mouse.wheel(0, -240); await page.waitForTimeout(120); } await page.waitForTimeout(700);
  const s1 = await size();
  ok('wheel: the edge is in the middle of the screen', Math.hypot(s1.p[0] - cx, s1.p[1] - cy) < 5, `${Math.hypot(s1.p[0] - cx, s1.p[1] - cy).toFixed(1)} px from the middle`);
  ok('wheel: the view came closer', s1.wpp < s0.wpp * 0.8, `${(s0.wpp / s1.wpp).toFixed(2)}× closer`);
  ok('wheel: the manipulator kept its size on the screen', Math.abs(s1.arm - s0.arm) < 0.06 * s0.arm && s0.arm > 40, `${s0.arm.toFixed(1)} px → ${s1.arm.toFixed(1)} px`);
  const f0 = await page.evaluate(() => { const b = document.getElementById('c9Ang').getBoundingClientRect(); return b.height; });
  ok('wheel: the numbers kept their size', f0 > 10 && f0 < 40, `${f0.toFixed(0)} px high`);
  await page.screenshot({ path: path.join(outDir, 'section_close.png') });

  // dragging the arc with the mouse: free, then whole degrees, then held square
  const drag = async (kind, dx, dy) => { const h = await page.evaluate(k => __c9.handle(k), kind); await page.mouse.move(h[0], h[1]); await page.mouse.down(); for (let i = 1; i <= 6; i++) { await page.mouse.move(h[0] + dx * i / 6, h[1] + dy * i / 6); await page.waitForTimeout(40); } await page.mouse.up(); await page.waitForTimeout(250); };
  await page.evaluate(E => { __c9.run('quantAngle', { edge: E, side: 'a', mode: 'off' }); __c9.run('setAngle', { edge: E, side: 'a', angle: 90 }); }, E); await page.waitForTimeout(200);
  const perp = await page.evaluate(() => __c9.handleDir()); let a0 = await page.evaluate(E => __c9.corner(E).angle, E), u0 = await page.evaluate(() => __scan.undo.length);
  await drag('rot', perp[0] * 22, perp[1] * 22); let a1 = await page.evaluate(E => __c9.corner(E).angle, E), u1b = await page.evaluate(() => __scan.undo.length);
  ok('manipulator: dragging the arc turns the face', Math.abs(a1 - a0) > 0.5, `${a0.toFixed(3)}° → ${a1.toFixed(3)}°`);
  ok('manipulator: one drag is one step of Undo', u1b - u0 === 1);
  await page.evaluate(E => __c9.run('quantAngle', { edge: E, side: 'a', mode: 'deg' }), E); await page.waitForTimeout(150);
  const p2 = await page.evaluate(() => __c9.handleDir()); await drag('rot', p2[0] * 31, p2[1] * 31); const a2 = await page.evaluate(E => __c9.corner(E).angle, E);
  ok('manipulator: with 1° on, the angle jumps by whole degrees', Math.abs(a2 - Math.round(a2)) < 1e-6 && Math.abs(a2 - a1) > 0.5, `${a2}°`);
  await page.evaluate(E => __c9.run('quantAngle', { edge: E, side: 'a', mode: '90' }), E); await page.waitForTimeout(150);
  const p3 = await page.evaluate(() => __c9.handleDir()), b3 = await page.evaluate(() => T.snap()), u3 = await page.evaluate(() => __scan.undo.length); await drag('rot', p3[0] * 30, p3[1] * 30);
  const l3 = await page.evaluate(() => ({ same: null, msg: __c9.state.msg, blink: !!document.querySelector('#c9qa button.c9blink'), undo: __scan.undo.length }));
  ok('manipulator: with 90° on, the face does not move', b3 === await page.evaluate(() => T.snap()) && l3.undo === u3);
  ok('manipulator: the control that holds it says so', /square/.test(l3.msg || ''), l3.msg);
  // the arrow
  await page.evaluate(E => { __c9.run('quantSize', { edge: E, side: 'b', on: false }); }, E); await page.waitForTimeout(150);
  const m0 = await page.evaluate(E => __c9.corner(E), E), pm = await page.evaluate(() => __c9.handleDir()); await drag('mov', pm[0] * 25, pm[1] * 25); const m1 = await page.evaluate(E => __c9.corner(E), E);
  ok('manipulator: dragging the arrow moves the face parallel to itself', Math.abs(m1.lenB - m0.lenB) > 0.05 && Math.abs(m1.angle - m0.angle) < 1e-6, `other face ${m0.lenB.toFixed(3)} → ${m1.lenB.toFixed(3)} mm, angle ${m1.angle}°`);
  await page.evaluate(E => __c9.run('quantSize', { edge: E, side: 'b', on: true }), E); await page.waitForTimeout(150);
  const pm2 = await page.evaluate(() => __c9.handleDir()), m2a = await page.evaluate(E => __c9.corner(E), E); await drag('mov', pm2[0] * 40, pm2[1] * 40); const m2 = await page.evaluate(E => __c9.corner(E), E);
  ok('manipulator: with the size held, the arrow moves by whole millimetres', Math.abs(m2.lenB - Math.round(m2.lenB)) < 1e-6 && m2.sizeHeldTo[1] === 1, `${m2a.lenB} → ${m2.lenB} mm`);
  // Redo
  const rd = await page.evaluate(E => { __c9.run('quantAngle', { edge: E, side: 'a', mode: 'off' }); __c9.run('setAngle', { edge: E, side: 'a', angle: 93.25 }); const a = __c9.corner(E).angle; __c9.run('undo'); const b = __c9.corner(E).angle, n1 = __scan.redo.length; __c9.run('redo'); const c = __c9.corner(E).angle, n2 = __scan.redo.length; __c9.run('undo'); __c9.run('setAngle', { edge: E, side: 'a', angle: 91 }); return { a, b, c, n1, n2, n3: __scan.redo.length, btn: !!document.getElementById('scRedo') }; }, E);
  ok('redo: brings back what Undo took away', Math.abs(rd.a - 93.25) < 1e-6 && Math.abs(rd.b - 93.25) > 0.1 && Math.abs(rd.c - 93.25) < 1e-6 && rd.n1 === 1 && rd.n2 === 0 && rd.btn, `${rd.a}° → undo ${rd.b}° → redo ${rd.c}°`);
  ok('redo: a new change lets the old future go', rd.n3 === 0);
  await page.evaluate(E => { __c9.run('quantAngle', { edge: E, side: 'a', mode: '90' }); __c9.run('openSection', { edge: E, at: 0.5, side: 'a' }); }, E); await page.waitForTimeout(600);
  // the boxes: clear of the handles, and they go where they are dragged
  const lay = () => page.evaluate(() => { const hs = [__c9.handle('rot'), __c9.handle('mov'), ...__c9.ends()]; const bx = ['c9A', 'c9La', 'c9Lb'].map(id => { const b = document.getElementById(id).getBoundingClientRect(); return [b.left, b.top, b.right, b.bottom]; }); const over = bx => bx.some((a, i) => bx.some((b, j) => j > i && a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1])); return { over: over(bx), covered: hs.filter(h => bx.some(b => h[0] > b[0] - 2 && h[0] < b[2] + 2 && h[1] > b[1] - 2 && h[1] < b[3] + 2)).length, bx, arm: __c9.pix().arm }; });
  const l0 = await lay(); ok('boxes: none lies on a handle of the manipulator', l0.covered === 0, `${l0.covered} handles covered`);
  ok('boxes: none lies on another', !l0.over);
  ok('manipulator: one and a half times the first size', l0.arm > 120, `arm ${l0.arm.toFixed(0)} px on the screen (in the plane, seen at an angle)`);
  const b0 = l0.bx[1]; await page.mouse.move(b0[0] + 5, b0[3] - 5); await page.mouse.down(); for (let i = 1; i <= 5; i++) { await page.mouse.move(b0[0] + 5 - 30 * i, b0[3] - 5 - 24 * i); await page.waitForTimeout(30); } await page.mouse.up(); await page.waitForTimeout(200);
  const l1 = await lay(); ok('boxes: a box is dragged with the mouse', Math.abs(l1.bx[1][0] - (b0[0] - 150)) < 3 && Math.abs(l1.bx[1][1] - (b0[1] - 120)) < 3, `moved by ${(l1.bx[1][0] - b0[0]).toFixed(0)}, ${(l1.bx[1][1] - b0[1]).toFixed(0)} px`);
  await page.evaluate(E => __c9.run('activeSide', { side: 'b' }), E); await page.waitForTimeout(300); const l2 = await lay();
  ok('boxes: a moved box stays where it was put', Math.abs(l2.bx[1][0] - l1.bx[1][0]) < 2 && Math.abs(l2.bx[1][1] - l1.bx[1][1]) < 2);
  await page.evaluate(() => document.querySelector('#c9La .c9home').click()); await page.waitForTimeout(200); const l4 = await lay();
  ok('boxes: its small button sends it back beside the corner', Math.hypot(l4.bx[1][0] - l1.bx[1][0], l4.bx[1][1] - l1.bx[1][1]) > 40 && l4.covered === 0);
  await page.evaluate(E => __c9.run('activeSide', { side: 'a' }), E); await page.waitForTimeout(300);
  // typing in the box
  const held0 = await page.evaluate(E => __c9.corner(E).angleHeldTo, E);
  const t1 = await page.evaluate(E => { const inp = document.getElementById('c9Ang'); inp.value = '87.5'; inp.dispatchEvent(new Event('change', { bubbles: true })); return ({ st: __c9.corner(E), blink: !!document.querySelector('#c9qa button.c9blink'), on: !!document.querySelector('#c9qa button.on'), drops: __c9.state.drops.slice(-3).map(d => d.key + '@' + Math.round(performance.now() - d.t)) }); }, E);
  ok('edit box: 87.5 typed into the angle is taken, the 90° button goes off and blinks', Math.abs(t1.st.angle - 87.5) < 1e-6 && t1.st.angleHeldTo === null && !t1.on && t1.blink, `${t1.st.angle}°, was held to ${held0}, on ${t1.on}, blink ${t1.blink}, drops ${t1.drops.join(' ')}`);
  await page.screenshot({ path: path.join(outDir, 'section_edited.png') });

  // 8. a right click on an edge opens its section there
  await page.evaluate(() => __c9.run('closeSection')); await page.waitForTimeout(200);
  const ep = await page.evaluate(E => __c9.edgePoint(E, 0.3), E); await page.mouse.click(ep[0], ep[1], { button: 'right' }); await page.waitForTimeout(400);
  const rc = await page.evaluate(() => { const s = __c9.state.sec, X = T.X(); return s ? { level: (s.level - X.t0) / (X.t1 - X.t0), sel: __scan.sel } : null; });
  ok('right click on an edge opens the section at the point clicked', !!rc && Math.abs(rc.level - 0.3) < 0.06, rc ? `at ${(rc.level * 100).toFixed(0)} % of the edge` : 'nothing opened');

  // 8b. the marks of the corners are large and can be hit; an edge at an end of the body is picked with a right click
  const mk = await page.evaluate(() => __c9.marks()); ok('marks of the corners: twice the first size', mk.length > 0 && mk.every(v => v >= 16), mk.join(', ') + ' px');
  await page.evaluate(() => { __c9.run('closeSection'); __c9.run('select', {}); }); await page.waitForTimeout(300);
  const vp = await page.evaluate(E => __c9.edgePoint(E, 1), E); await page.mouse.click(vp[0] + 6, vp[1] + 5); await page.waitForTimeout(400);
  ok('marks of the corners: a click on a mark picks its edge', await sels() === 'edge' + E, await sels());
  const F = await page.evaluate(E => __scan.rec.extr.corners.find(c => c.i === E).j, E);
  await page.evaluate(F => __c9.run('select', { type: 'face', i: F }), F); await page.waitForTimeout(300);
  const rps = await page.evaluate(F => [0, 1].map(end => ({ end, p: __c9.rimPoint(F, end, 0.5) })), F), rp = rps.find(q => q.p[0] > 330 && q.p[0] < 1050 && q.p[1] > 70 && q.p[1] < 880) || rps[0];
  await page.mouse.click(rp.p[0], rp.p[1], { button: 'right' }); await page.waitForTimeout(500);
  const rm = await page.evaluate(() => ({ sel: __scan.sel, go: document.querySelectorAll('.c9rimgo').length, fat: __c9.fat(), wide: (__scan.bodyObjs || []).filter(o => o.userData.fat).length, text: (document.querySelector('.c9rimgo') || {}).textContent || '' }));
  ok('edge at an end of the body: a right click on it picks it', !!rm.sel && rm.sel.type === 'rim' && rm.sel.i === F && rm.sel.end === rp.end, JSON.stringify(rm.sel));
  ok('edge at an end of the body: shown as a wide yellow line, with its length and its two corners in the Edit panel', rm.go === 2 && rm.fat && rm.wide === 1, `${rm.go} buttons, wide lines ${rm.fat ? 'loaded' : 'not loaded'}`);
  await page.screenshot({ path: path.join(outDir, 'rim.png') });
  await page.evaluate(() => document.querySelector('.c9rimgo').click()); await page.waitForTimeout(400);
  const rg = await page.evaluate(() => { const s = __c9.state.sec, X = T.X(); return s ? { at: (s.level - X.t0) / (X.t1 - X.t0), side: s.side } : null; });
  ok('edge at an end of the body: its button opens the section at its corner, at that end', !!rg && Math.abs(rg.at - rp.end) < 1e-9, JSON.stringify(rg));

  // 9. the tools of 08 still work, and mark what they put on the grid
  const q = await page.evaluate(() => { __c9.run('closeSection'); __c9.run('select', {}); const u = __scan.undo.length; __c9.run('squareFaces', { within: 2 }); __c9.run('quantSizes', { step: 1 }); const X = T.X(); return { undo: __scan.undo.length - u, held: X.ents.filter(e => e.qa).length, sizes: X.ents.filter(e => e.ql).length, n: X.ents.length }; });
  ok('Quantise of 08: works through the same door, each press one step of Undo', q.undo === 2);
  ok('Quantise of 08: corners and sizes that landed on the grid are marked as held', q.held > 5 && q.sizes > 5, `${q.held} corners, ${q.sizes} sizes of ${q.n}`);
  await page.waitForTimeout(300); await page.screenshot({ path: path.join(outDir, 'quantised.png') });

  // 10. records
  const ex = await page.evaluate(() => { const e = __c9.state.exp, p = JSON.parse(__scanFn.scProject()); return { n: e.length, withMeas: e.filter(r => r.measured && r.measured.angle !== null).length, refused: e.filter(r => !r.ok).length, cmds: __c9.list().length, proj: !!(p.body && p.body.measuredProfile && p.body.measuredProfile.length), ids: p.body.elements.every(x => x.id) }; });
  ok('experience: every command left a record, with what the scan measured', ex.n > 20 && ex.withMeas > 10 && ex.refused >= 1, `${ex.n} records, ${ex.withMeas} with the measured angle, ${ex.refused} refused`);
  ok('commands: the list names them all', ex.cmds >= 21, `${ex.cmds} commands`);
  ok('project file: keeps the measured profile and the numbers of the elements', ex.proj && ex.ids);
  ok('no errors in the page', errors.length === 0, errors.slice(0, 3).join(' | '));

  fs.writeFileSync(path.join(outDir, 'test09.txt'), rows.join('\n') + `\n\n${pass} passed, ${fail} failed\n`);
  console.log(`\n${pass} passed, ${fail} failed`);
  await browser.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FAILED', e.message.split('\n')[0]); console.log(`\n${pass} passed, ${fail} failed (stopped)`); process.exit(2); });
