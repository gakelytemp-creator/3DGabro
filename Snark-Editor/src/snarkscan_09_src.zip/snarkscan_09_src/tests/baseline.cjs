// Baseline: run a SnarkScan page on a scan and record what it recognises. Reads only.
// usage: node baseline.cjs <page.html> <scan.obj> <out.json>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const [page_, scan, out] = process.argv.slice(2);
const THREE_DIR = path.join(__dirname, 'node_modules/three');
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--js-flags=--max-old-space-size=8192'] });
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => { errors.push('dialog: ' + d.message()); d.dismiss(); });
  await page.route('https://cdn.jsdelivr.net/npm/three@0.180.0/**', r => {
    const rel = r.request().url().split('three@0.180.0/')[1], f = path.join(THREE_DIR, rel);
    if (fs.existsSync(f)) r.fulfill({ body: fs.readFileSync(f), contentType: 'text/javascript' }); else r.abort();
  });
  await page.goto('file://' + path.resolve(page_));
  await page.waitForFunction(() => window.__scan && window.__scanFn, null, { timeout: 60000 });
  const t0 = Date.now();
  await page.setInputFiles('#fileScan', scan);
  await page.waitForFunction(() => window.__scan.n > 0 && !document.body.classList.contains('busy'), null, { timeout: 420000, polling: 500 });
  console.log('opened', await page.evaluate(() => __scan.n), 'points', ((Date.now() - t0) / 1000).toFixed(1), 's');
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="orient"]').click());
  await page.waitForFunction(() => window.__scan.frame, null, { timeout: 420000, polling: 500 });
  console.log('oriented', ((Date.now() - t0) / 1000).toFixed(1), 's');
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="recognise"]').click());
  await page.waitForFunction(() => window.__scan.rec, null, { timeout: 480000, polling: 500 });
  console.log('recognised', ((Date.now() - t0) / 1000).toFixed(1), 's');
  const res = await page.evaluate(() => {
    const S = __scan, X = S.rec.extr, r = v => Math.round(v * 1e4) / 1e4;
    const o = { points: S.n, frame: { how: S.frame.how, kind: S.frame.kind }, planes: S.rec.planes && S.rec.planes.length, edges: S.rec.edges && S.rec.edges.length, cyls: S.rec.cyls && S.rec.cyls.length, cards: S.rec.journal && S.rec.journal.cards.length };
    if (X) o.extr = { k: X.k, t0: r(X.t0), t1: r(X.t1), closed: !!X.closed, corners: X.corners && X.corners.length,
      ents: X.ents.map(e => e.t === 'line' ? { t: 'line', p0: e.p0.map(r), p1: e.p1.map(r), on: e.on, off: e.off, guess: !!e.guess } : { t: e.t, c: e.c.map(r), r: r(e.r), p0: e.p0.map(r), p1: e.p1.map(r), ccw: !!e.ccw, on: e.on, off: e.off, guess: !!e.guess }) };
    return o;
  });
  res.errors = errors; res.seconds = (Date.now() - t0) / 1000;
  fs.writeFileSync(out, JSON.stringify(res, null, 1));
  await page.screenshot({ path: out.replace(/\.json$/, '.png') });
  const X = res.extr;
  console.log(JSON.stringify({ ...res, extr: X ? { k: X.k, t0: X.t0, t1: X.t1, closed: X.closed, corners: X.corners, ents: X.ents.length, lines: X.ents.filter(e => e.t === 'line').length, arcs: X.ents.filter(e => e.t !== 'line').length, guess: X.ents.filter(e => e.guess).length } : null }));
  await browser.close();
})().catch(e => { console.error('FAILED', e.message); process.exit(1); });
