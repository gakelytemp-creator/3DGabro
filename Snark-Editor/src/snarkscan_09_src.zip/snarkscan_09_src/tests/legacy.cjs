// The tools of 08 give the same body in 09: both pages do the same presses, the profiles are compared.
// usage: node legacy.cjs <scan.obj> <08.html> <09.html> <outdir>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'), path = require('path');
const [scan, p08, p09, outDir] = process.argv.slice(2), THREE_DIR = path.join(__dirname, 'node_modules/three');
async function run(pageFile, shot) {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--js-flags=--max-old-space-size=8192'] });
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } }); const errors = []; page.on('pageerror', e => errors.push(String(e)));
  await page.route('https://cdn.jsdelivr.net/npm/three@0.180.0/**', r => { const f = path.join(THREE_DIR, r.request().url().split('three@0.180.0/')[1]); fs.existsSync(f) ? r.fulfill({ body: fs.readFileSync(f), contentType: 'text/javascript' }) : r.abort(); });
  await page.goto('file://' + path.resolve(pageFile)); await page.waitForFunction(() => window.__scan && window.__scanFn, null, { timeout: 60000 });
  await page.setInputFiles('#fileScan', scan); await page.waitForFunction(() => window.__scan.n > 0 && !document.body.classList.contains('busy'), null, { timeout: 420000, polling: 500 });
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="orient"]').click()); await page.waitForFunction(() => window.__scan.frame, null, { timeout: 420000, polling: 500 });
  await page.evaluate(() => document.querySelector('#scanTools button[data-tool="recognise"]').click()); await page.waitForFunction(() => window.__scan.rec, null, { timeout: 480000, polling: 500 }); await page.waitForTimeout(1000);
  const dump = () => page.evaluate(() => __scan.rec.extr.ents.map(e => ({ t: e.t, p0: e.p0, p1: e.p1, c: e.c || null, r: e.r || null })));
  const steps = {};
  await page.evaluate(() => __scanFn.scBodySquare(null, 2)); steps.square = await dump();
  await page.evaluate(() => __scanFn.scQuantSizes(1)); steps.sizes = await dump();
  await page.evaluate(() => __scanFn.scBodyDelete(3)); steps.deleted = await dump();
  await page.evaluate(() => __scanFn.scUndo()); steps.undone = await dump();
  if (shot) { await page.waitForTimeout(500); await page.screenshot({ path: path.join(outDir, 'quantised_clean.png') });
    const info = await page.evaluate(() => { const X = __scan.rec.extr, c = X.corners.filter(q => X.ents[q.i].t === 'line' && X.ents[q.j].t === 'line').map(q => ({ i: q.i, st: __c9.corner(q.i) })).sort((a, b) => Math.min(b.st.lenA, b.st.lenB) - Math.min(a.st.lenA, a.st.lenB))[0]; __c9.run('openSection', { edge: c.i, at: 0.5, side: 'a' }); return { edge: c.i, st: __c9.corner(c.i), held: X.ents.filter(e => e.qa).length, sizes: X.ents.filter(e => e.ql).length, n: X.ents.length }; });
    const cv = await page.evaluate(() => { const r = document.getElementById('view').getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; });
    await page.mouse.move(cv[0], cv[1]); for (let i = 0; i < 5; i++) { await page.mouse.wheel(0, -240); await page.waitForTimeout(150); } await page.waitForTimeout(1200);
    await page.screenshot({ path: path.join(outDir, 'quantised_section.png') }); console.log('09 after Quantise:', JSON.stringify(info)); }
  await browser.close(); return { steps, errors };
}
(async () => {
  const a = await run(p08, false), b = await run(p09, true); let fail = 0;
  for (const k of Object.keys(a.steps)) { const A = a.steps[k], B = b.steps[k]; let worst = 0, same = A.length === B.length; if (same) A.forEach((e, i) => { if (e.t !== B[i].t) same = false; for (const q of ['p0', 'p1']) for (let j = 0; j < 2; j++) worst = Math.max(worst, Math.abs(e[q][j] - B[i][q][j])); if (e.r) worst = Math.max(worst, Math.abs(e.r - B[i].r)); });
    const ok = same && worst < 1e-9; if (!ok) fail++; console.log(`${ok ? 'PASS' : 'FAIL'}  08 = 09 after "${k}"  — ${A.length} / ${B.length} elements, largest difference ${worst.toExponential(2)} mm`); }
  console.log(`errors: 08 ${a.errors.length}, 09 ${b.errors.length}`); process.exit(fail || b.errors.length ? 1 : 0);
})().catch(e => { console.error('FAILED', e.message.split('\n')[0]); process.exit(2); });
