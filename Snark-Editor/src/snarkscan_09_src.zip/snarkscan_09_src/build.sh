#!/bin/sh
# builds SnarkScan_09.html from SnarkScan_08.html and checks the script for syntax
set -e
python3 build09.py "${1:-/home/claude/ss08/SnarkScan_08.html}" correct09.js SnarkScan_09.html
python3 - <<'P'
s=open('SnarkScan_09.html',encoding='utf-8').read(); a=s.index('<script type="module">',s.index('importmap')); b=s.index('</script>',a)
open('check09.mjs','w',encoding='utf-8').write(s[a+len('<script type="module">'):b])
P
node --check check09.mjs && echo SYNTAX_OK
