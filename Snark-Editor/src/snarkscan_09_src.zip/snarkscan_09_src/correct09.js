/* ══════════ SnarkScan_09: the correction tool ══════════
   What is new in 09 lives here; the recognition of 08 is untouched.

   State
     X.meas            the profile as the scan gave it, copied once after Recognise and never changed: the measured values
     X.ents            the profile being worked on: the nominal values (as in 08)
     e.id              a number an element keeps through every change and Undo
     e.ql              a flat face: the step (mm) its length is held to, or nothing; a round face: the step of its radius
     e.qa              the corner after this element: '90' | '45' | 'deg' — what its angle is held to, or nothing
   A flag is true only while its value lies on its grid. Whatever takes the value off the grid drops the flag, and the
   control that shows it blinks: the rules never fight in silence.

   Commands
     c9Run(name, args) is the one door for every action of this tool: it keeps Undo, does the work, writes a record of
     what was measured, what stood before and what stands now (C9.exp, the experience), and draws. The buttons, the
     manipulator, the tests and — later — a language model all call the same commands. __c9.list() names them.

   The section at an edge
     A right click on an edge opens a see-through plane square to the edge at the point clicked. On it: the outline of
     the part in that plane (faint), the two faces that meet at the edge, the angle between them, their lengths, the
     axes of the part, and a flat manipulator on the active face: an arc at its far end turns it about the edge, an
     arrow moves it parallel to itself. The other face stands still, everything else is frozen; the face next after the
     moved one is taken as an endless line (a round one as its whole circle) and the new corner is where they cross. */
const C9_PX = { axis: 142, ray: 225, arc: 45, rot: 188, rotHalf: 0.26, mov: 105, movHalf: 40, head: 15, knobRot: 11, knobMov: 10 };
const C9 = { pin: {}, sels: [], sec: null, exp: [], expLoaded: [], drag: null, msg: '', drops: [], q: { aStep: 1 }, nextId: 1, seq: 0, showMeas: false, G: null };
const c9X = () => (SCAN.rec && SCAN.rec.extr && SCAN.tool === 'recognise' ? SCAN.rec.extr : null);
const c9Step = () => (SCAN.quant && SCAN.quant.sStep > 0 ? SCAN.quant.sStep : 1);
const c9Cross = (a, b) => a[0] * b[1] - a[1] * b[0];
const c9Grid = (v, step, tol = 1e-6) => Math.abs(v - Math.round(v / step) * step) < tol;
const c9Fmt = (v, d = 3) => String(Math.round(v * 10 ** d) / 10 ** d);
function c9P3(X, pt, t) { const k = X.k, [i0, j0] = [0, 1, 2].filter(q => q !== k), q = [0, 0, 0]; q[k] = t; q[i0] = pt[0]; q[j0] = pt[1]; return q; }
const c9Same = (q, type, i, end) => q.type === type && q.i === i && (type !== 'rim' || (q.end ? 1 : 0) === (end ? 1 : 0));
function c9Sel(type, i, end) { return C9.sels.some(q => c9Same(q, type, i, end)); }
function c9AngOk(mode, deg) { return mode === '90' ? Math.abs(deg - 90) < 1e-5 : mode === '45' ? c9Grid(deg, 45, 1e-5) : mode === 'deg' ? c9Grid(deg, C9.q.aStep, 1e-5) : true; }
function c9Ang(X, c) { const da = scElDir(X.ents[c.i], c.ka), db = scElDir(X.ents[c.j], c.kb); return Math.acos(Math.max(-1, Math.min(1, da[0] * db[0] + da[1] * db[1]))) * 180 / Math.PI; }
function c9Drop(key) { C9.drops.push({ key, t: performance.now() }); if (C9.drops.length > 40) C9.drops.shift(); }

/* called at the head of every build of the body: numbers for new elements, the measured copy, the pick kept in step, stale size flags dropped */
function c9Sync(X) {
  for (const e of X.ents) if (!e.id) e.id = C9.nextId++; else if (e.id >= C9.nextId) C9.nextId = e.id + 1;
  if (!X.meas) SCAN.redo = [];
  if (!X.meas) X.meas = X.ents.map(e => JSON.parse(JSON.stringify({ id: e.id, t: e.t, p0: e.p0, p1: e.p1, c: e.c, r: e.r, ccw: e.ccw, guess: !!e.guess, on: e.on || 0, off: e.off || 0 })));
  const S = SCAN.sel; if (!S) C9.sels = []; else if (!c9Sel(S.type, S.i, S.end)) C9.sels = [{ type: S.type, i: S.i, end: S.end }];
  C9.sels = C9.sels.filter(q => q.type !== 'rim' || q.i < X.ents.length);
  for (const e of X.ents) if (e.ql) { if (e.t === 'line') { scSpan(e); if (!c9Grid(scElLen(e), e.ql)) { e.ql = 0; c9Drop('ql' + e.id); } } else if (!c9Grid(e.r, e.ql)) { e.ql = 0; c9Drop('ql' + e.id); } }
}
/* called at the end of every build, when the corners are known: stale angle flags dropped, the marks of the corners made */
const C9_RED = [0.89, 0.16, 0.16];
function c9SideCol(e) { return scDoubt(e) ? C9_RED : e.t === 'line' ? (e.ql ? [0.02, 0.18, 0.55] : [0.32, 0.6, 0.93]) : (e.ql ? [0.32, 0.1, 0.62] : [0.66, 0.5, 0.96]); }
function c9EdgeCol(A, B) { return scDoubt(A) || scDoubt(B) ? C9_RED : A.qa ? [0.06, 0.1, 0.22] : [0.42, 0.52, 0.68]; }
/* the colour of an edge along the body; on the way the angle flag of its corner is dropped if the angle left its grid */
function c9EdgeKc(A, B, gap, ka, kb, sel) { if (A.qa) { const da = scElDir(A, ka), db = scElDir(B, kb), th = Math.acos(Math.max(-1, Math.min(1, da[0] * db[0] + da[1] * db[1]))) * 180 / Math.PI; if (gap > 0.05 || !c9AngOk(A.qa, th)) { A.qa = null; c9Drop('qa' + A.id); } } return sel ? [1, 0.82, 0] : c9EdgeCol(A, B); }
function c9Vertices(X) {
  const sq = [[], []], ci = [[], []];
  for (const c of X.corners) { const A = X.ents[c.i], B = X.ents[c.j];
    const col = c9Sel('edge', c.i) ? [1, 0.82, 0] : c9EdgeCol(A, B), T = A.qa ? sq : ci; for (const p of [c.a3, c.b3]) { T[0].push(...p); T[1].push(...col); } }
  X.vSq = { pos: new Float32Array(sq[0]), col: new Float32Array(sq[1]) }; X.vCi = { pos: new Float32Array(ci[0]), col: new Float32Array(ci[1]) };
}

/* ── geometry of the profile ── */
function c9LineLine(P, d, Q, e) { const cr = c9Cross(d, e); if (Math.abs(cr) < 1e-12) return null; const s = c9Cross([Q[0] - P[0], Q[1] - P[1]], e) / cr; return [P[0] + s * d[0], P[1] + s * d[1]]; }
function c9LineCircle(P, d, c, r, near) { const f = [P[0] - c[0], P[1] - c[1]], b = f[0] * d[0] + f[1] * d[1], D = b * b - (f[0] * f[0] + f[1] * f[1] - r * r); if (D < 0) return null; const sq = Math.sqrt(D), pts = [-b - sq, -b + sq].map(s => [P[0] + s * d[0], P[1] + s * d[1]]); return Math.hypot(pts[0][0] - near[0], pts[0][1] - near[1]) <= Math.hypot(pts[1][0] - near[0], pts[1][1] - near[1]) ? pts[0] : pts[1]; }
/* the flat face `idx` is laid on the line through Q along d. Its ends are set anew where that line crosses its neighbours,
   each taken as endless (a line) or whole (a circle); `fixedKey` names an end that stays at Q (the edge a face turns about).
   Nothing is changed unless everything fits. */
function c9SetLine(X, idx, Q, d, fixedKey) {
  const A = X.ents[idx]; if (!A || A.t !== 'line') return { ok: false, why: 'only a flat face can be turned or moved' };
  const l = Math.hypot(d[0], d[1]); if (!(l > 1e-12)) return { ok: false, why: 'no direction' }; d = [d[0] / l, d[1] / l];
  const joints = [], cp = X.corners.find(c => c.j === idx), cn = X.corners.find(c => c.i === idx);
  if (cp && cp.i !== idx) joints.push({ kA: cp.kb, N: X.ents[cp.i], kN: cp.ka, gap: cp.gap }); if (cn && cn.j !== idx) joints.push({ kA: cn.ka, N: X.ents[cn.j], kN: cn.kb, gap: cn.gap });
  if (joints.length === 2 && joints[0].kA === joints[1].kA) return { ok: false, why: 'this face meets both of its neighbours at one end' };
  const np = {}, moves = [];
  for (const key of ['p0', 'p1']) { const j = joints.find(q => q.kA === key);
    if (key === fixedKey) { np[key] = [...Q]; continue; }
    if (!j || j.gap > 0.05) { const o = A[key], s = (o[0] - Q[0]) * d[0] + (o[1] - Q[1]) * d[1]; np[key] = [Q[0] + s * d[0], Q[1] + s * d[1]]; continue; }
    const N = j.N, old = N[j.kN]; let Xp;
    if (N.t === 'line') { const e = [N.p1[0] - N.p0[0], N.p1[1] - N.p0[1]], el = Math.hypot(e[0], e[1]); if (el < 1e-9 || Math.abs(c9Cross(d, e)) < 1e-6 * el) return { ok: false, why: 'the face would run parallel to the next one: they no longer cross' }; Xp = c9LineLine(Q, d, N.p0, e); }
    else { Xp = c9LineCircle(Q, d, N.c, N.r, old); if (!Xp) return { ok: false, why: 'the face would miss the round face next to it' }; }
    np[key] = Xp; moves.push({ N, kN: j.kN, to: Xp }); }
  const v = [np.p1[0] - np.p0[0], np.p1[1] - np.p0[1]]; if (Math.hypot(v[0], v[1]) < 1e-4) return { ok: false, why: 'the face would shrink to nothing' };
  if (fixedKey) { const far = fixedKey === 'p0' ? 'p1' : 'p0'; if ((np[far][0] - np[fixedKey][0]) * d[0] + (np[far][1] - np[fixedKey][1]) * d[1] <= 0) return { ok: false, why: 'the next face lies behind the edge in that direction' }; }
  else if (v[0] * (A.p1[0] - A.p0[0]) + v[1] * (A.p1[1] - A.p0[1]) <= 0) return { ok: false, why: 'the face would be turned end for end' };
  for (const m of moves) { const N = m.N; if (N.t === 'line') { const o = N[m.kN === 'p0' ? 'p1' : 'p0'], was = [N[m.kN][0] - o[0], N[m.kN][1] - o[1]], now = [m.to[0] - o[0], m.to[1] - o[1]]; if (Math.hypot(now[0], now[1]) < 1e-4 || was[0] * now[0] + was[1] * now[1] <= 0) return { ok: false, why: `the next face is only ${c9Fmt(Math.hypot(was[0], was[1]), 3)} mm long and would be used up: change less, or delete that face first` }; }
    else { scSpan(N); const t = Object.assign({}, N, { [m.kN]: m.to }); scSpan(t); if (t.sw < 1e-4 || Math.abs(t.sw - N.sw) > Math.PI) return { ok: false, why: 'the round face next to it would be turned inside out' }; } }
  A.p0 = np.p0; A.p1 = np.p1; for (const m of moves) m.N[m.kN] = [...m.to]; return { ok: true };
}
/* the two faces of a corner, seen from one of them: `side` 'a' is the element before the edge, 'b' the one after */
function c9Sides(X, c, side) { const A = X.ents[c.i], B = X.ents[c.j], a = side === 'a'; return { act: a ? A : B, oth: a ? B : A, ka: a ? c.ka : c.kb, ko: a ? c.kb : c.ka, ia: a ? c.i : c.j, io: a ? c.j : c.i, A, B }; }
function c9SetAngle(X, c, side, deg) {
  const s = c9Sides(X, c, side); if (s.act.t !== 'line') return { ok: false, why: 'a round face cannot be turned here: make the flat one active' }; if (c.gap > 0.05) return { ok: false, why: 'the two faces do not meet at this edge' };
  if (!(deg > 0.01 && deg < 179.99)) return { ok: false, why: 'the angle must lie between 0° and 180°' };
  const P = [...s.act[s.ka]], da = scElDir(s.act, s.ka), dq = scElDir(s.oth, s.ko), a = (c9Cross(dq, da) >= 0 ? 1 : -1) * deg * Math.PI / 180;
  return c9SetLine(X, s.ia, P, [dq[0] * Math.cos(a) - dq[1] * Math.sin(a), dq[0] * Math.sin(a) + dq[1] * Math.cos(a)], s.ka);
}
function c9Shift(X, c, side, by) { const s = c9Sides(X, c, side); if (s.act.t !== 'line') return { ok: false, why: 'a round face cannot be moved here: make the flat one active' }; const P = s.act[s.ka], da = scElDir(s.act, s.ka); return c9SetLine(X, s.ia, [P[0] - da[1] * by, P[1] + da[0] * by], da, null); }
/* the length of the face `side` at this corner is set by moving the other face parallel to itself: the corner slides along the face whose length is asked for */
function c9SetLen(X, c, side, len) {
  const s = c9Sides(X, c, side), S = s.act, M = s.oth; if (S.t !== 'line') return { ok: false, why: 'a round face has no length to set here' }; if (M.t !== 'line') return { ok: false, why: 'the face beside it is round and stands where it is: its neighbour cannot be made longer or shorter from this edge' };
  if (!(len > 1e-4)) return { ok: false, why: 'the length must be more than nothing' }; if (c.gap > 0.05) return { ok: false, why: 'the two faces do not meet at this edge' };
  const F = S[s.ka === 'p0' ? 'p1' : 'p0'], dS = scElDir(S, s.ka); return c9SetLine(X, s.io, [F[0] - dS[0] * len, F[1] - dS[1] * len], scElDir(M, s.ko), null);
}
function c9Corner(X, edge) { return X.corners.find(c => c.i === edge) || null; }
function c9MeasOf(X, e) { return X.meas.find(m => m.id === e.id) || null; }
/* what the scan gave for this corner: the angle between the two elements as measured, and their lengths */
function c9Measured(X, c) { const ma = c9MeasOf(X, X.ents[c.i]), mb = c9MeasOf(X, X.ents[c.j]), o = { angle: null, lenA: null, lenB: null }; for (const m of [ma, mb]) if (m) scSpan(m); if (ma) o.lenA = ma.t === 'line' ? scElLen(ma) : null; if (mb) o.lenB = mb.t === 'line' ? scElLen(mb) : null;
  if (ma && mb) { let ka = 'p1', kb = 'p0', bd = Infinity; for (const x of ['p0', 'p1']) for (const y of ['p0', 'p1']) { const d = Math.hypot(ma[x][0] - mb[y][0], ma[x][1] - mb[y][1]); if (d < bd) { bd = d; ka = x; kb = y; } } const da = scElDir(ma, ka), db = scElDir(mb, kb); o.angle = Math.acos(Math.max(-1, Math.min(1, da[0] * db[0] + da[1] * db[1]))) * 180 / Math.PI; } return o; }
function c9State(X, edge) { const c = c9Corner(X, edge); if (!c) return null; const A = X.ents[c.i], B = X.ents[c.j]; scSpan(A); scSpan(B); return { edge, ids: [A.id, B.id], kinds: [A.t, B.t], angle: +c9Fmt(c9Ang(X, c), 6), lenA: +c9Fmt(scElLen(A), 6), lenB: +c9Fmt(scElLen(B), 6), angleHeldTo: A.qa || null, sizeHeldTo: [A.ql || null, B.ql || null] }; }

/* ── the commands ── */
const c9Need = (X, a) => { const c = c9Corner(X, a.edge); return c ? { c, side: a.side === 'b' ? 'b' : 'a' } : null; };
const C9_CMDS = {
  setAngle: { args: 'edge, side, angle', does: 'the active face (side a or b) is turned about the edge until the angle between the two faces is `angle` degrees; the other face stands still', changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; return c9SetAngle(X, q.c, q.side, +a.angle); } },
  shift: { args: 'edge, side, by', does: 'the active face is moved parallel to itself by `by` mm; the edge slides along the other face', changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; return c9Shift(X, q.c, q.side, +a.by); } },
  setLength: { args: 'edge, side, length', does: 'the face `side` is given the length `length` mm by moving the other face of the edge parallel to itself', changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; return c9SetLen(X, q.c, q.side, +a.length); } },
  quantAngle: { args: 'edge, side, mode', does: "the angle at the edge is held to a grid: mode '90' (square), '45' (multiples of 45°), 'deg' (whole degrees) or 'off'; switching it on turns the active face onto the nearest value", changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; const A = X.ents[q.c.i]; if (a.mode === 'off' || !a.mode) { A.qa = null; return { ok: true }; }
      const th = c9Ang(X, q.c), st = C9.q.aStep, to = a.mode === '90' ? 90 : a.mode === '45' ? Math.max(45, Math.min(135, Math.round(th / 45) * 45)) : Math.max(st, Math.min(180 - st, Math.round(th / st) * st));
      if (Math.abs(to - th) > 1e-7) { const r = c9SetAngle(X, q.c, q.side, to); if (!r.ok) return r; } A.qa = a.mode; return { ok: true }; } },
  quantSize: { args: 'edge, side, on', does: 'the length of the face `side` is held to the step of sizes (1 mm unless changed in Quantise); switching it on moves the other face until the length is a whole number of steps', changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; const s = c9Sides(X, q.c, q.side), S = s.act; if (!a.on) { S.ql = 0; return { ok: true }; } if (S.t !== 'line') return { ok: false, why: 'the size of a round face is its radius: round it in Quantise' };
      scSpan(S); const st = c9Step(), L = scElLen(S), to = Math.max(st, Math.round(L / st) * st); if (Math.abs(to - L) > 1e-9) { const r = c9SetLen(X, q.c, q.side, to); if (!r.ok) return r; } S.ql = st; return { ok: true }; } },
  toMeasured: { args: 'edge, side', does: 'the active face is put back on the line the scan gave for it', changes: true,
    run(X, a) { const q = c9Need(X, a); if (!q) return { ok: false, why: 'no such edge' }; const s = c9Sides(X, q.c, q.side), m = c9MeasOf(X, s.act); if (!m || m.t !== 'line' || s.act.t !== 'line') return { ok: false, why: 'the scan has no flat face of this number' }; s.act.ql = 0; return c9SetLine(X, s.ia, m.p0, [m.p1[0] - m.p0[0], m.p1[1] - m.p0[1]], null); } },
  openSection: { args: 'edge, at, side', does: 'the plane square to the edge is opened at `at` (0 … 1 along the edge) with the manipulator on face `side`',
    run(X, a) { const c = c9Corner(X, a.edge); if (!c) return { ok: false, why: 'no such edge' }; const t = Math.max(0, Math.min(1, a.at === undefined ? 0.5 : +a.at)); C9.sec = { ida: X.ents[c.i].id, idb: X.ents[c.j].id, level: X.t0 + t * (X.t1 - X.t0), side: a.side === 'b' ? 'b' : 'a' }; SCAN.sel = { type: 'edge', i: c.i }; C9.sels = [{ type: 'edge', i: c.i }]; C9.msg = ''; return { ok: true }; } },
  closeSection: { args: '', does: 'the plane and the manipulator are put away', run() { C9.sec = null; C9.msg = ''; return { ok: true }; } },
  activeSide: { args: 'side', does: 'the manipulator is put on the other face of the open section', run(X, a) { if (!C9.sec) return { ok: false, why: 'no section is open' }; C9.sec.side = a.side === 'b' ? 'b' : 'a'; return { ok: true }; } },
  select: { args: 'type, i, end, add', does: "an element is picked as with the mouse: type 'face', 'edge' (along the body) or 'rim' (the edge of face i at end 0 or 1 of the body); add = true is a click with Shift", run(X, a) { c9Pick(a.type ? { type: a.type, i: +a.i, end: a.type === 'rim' ? (a.end ? 1 : 0) : undefined } : null, { shiftKey: !!a.add }, true); return { ok: true }; } },
  /* the tools of 08, through the same door (each keeps its own step of Undo) */
  deleteFace: { args: 'i', does: 'a face is declared an illusion and removed; its neighbours are carried on to meet', run(X, a) { scBodyDelete(+a.i); return { ok: true }; } },
  flatten: { args: 'i', does: 'a round face is made flat', run(X, a) { scBodyFlat(+a.i); return { ok: true }; } },
  smooth: { args: 'i, r', does: 'a round face is made to pass into both flat faces beside it with no corner', run(X, a) { return scBodyTangent(+a.i, +a.r || 0) ? { ok: true } : { ok: false, why: 'no arc touches both neighbours here' }; } },
  chamfer: { args: 'edge, size', does: 'a flat face is added at an edge', run(X, a) { scBodyChamfer(+a.edge, +a.size); return { ok: true }; } },
  round: { args: 'edge, r', does: 'an edge is rounded with a radius', run(X, a) { scBodyFillet(+a.edge, +a.r); return { ok: true }; } },
  mergeEdge: { args: 'edge', does: 'an edge is deleted: its two faces become one flat face', run(X, a) { scBodyMerge(+a.edge); return { ok: true }; } },
  quantAngles: { args: 'step, within, only', does: 'flat faces are turned onto multiples of `step` degrees from the axes', run(X, a) { scQuantAngles(+a.step, +a.within, a.only === undefined ? null : a.only); return { ok: true }; } },
  squareFaces: { args: 'only, within', does: 'flat faces are set exactly along the axes or the 45° diagonals', run(X, a) { scBodySquare(a.only === undefined ? null : a.only, +a.within || 0); return { ok: true }; } },
  quantSizes: { args: 'step', does: 'corners are moved onto a grid of `step` mm, radii and the length rounded', run(X, a) { scQuantSizes(+a.step); return { ok: true }; } },
  undo: { args: '', does: 'the last change of the body is taken back', run() { scUndo(); return { ok: true }; } },
  redo: { args: '', does: 'what Undo took away is brought back', run() { scRedo(); return { ok: true }; } }
};
function c9Record(name, args, before, after, ok, why) { const X = c9X(), c = X && args && args.edge !== undefined && after ? c9Corner(X, after.edge) : null, rec = { seq: C9.seq++, when: new Date().toISOString(), scan: SCAN.name, command: name, args, ok, why: why || null, measured: c ? c9Measured(X, c) : null, before, after }; C9.exp.push(rec);
  if (ok && C9_CMDS[name].changes && SCAN.rec) scUser('corrected at an edge: ' + name, { args, before, after, measured: rec.measured }); return rec; }
function c9Run(name, args = {}) {
  const def = C9_CMDS[name]; if (!def) return { ok: false, why: `no such command: ${name}` }; const X = c9X(); if (!X) return { ok: false, why: 'there is no body yet: Recognise first' };
  scBodyBuild(X); const before = args.edge !== undefined ? c9State(X, args.edge) : null, ids = before ? before.ids : null, redo0 = [...(SCAN.redo || [])]; if (def.changes) scKeep();
  let r; try { r = def.run(X, args) || { ok: true }; } catch (e) { r = { ok: false, why: String(e.message || e) }; }
  if (!r.ok) { if (def.changes) { const o = JSON.parse(SCAN.undo.pop()); X.ents = o.ents; SCAN.redo = redo0; scUndoBtn(); } C9.msg = r.why; c9Record(name, args, before, null, false, r.why); scBodyRedraw(); return r; }
  if (def.changes) C9.msg = ''; scBodyBuild(X); let after = null; if (ids) { const c = X.corners.find(q => X.ents[q.i].id === ids[0] && X.ents[q.j].id === ids[1]); if (c) after = c9State(X, c.i); }
  c9Record(name, args, before, after, true); scBodyRedraw(); return Object.assign({ before, after }, r);
}

/* ── Redo: what Undo took away is kept until the body is changed in a new way ── */
const c9Now = X => JSON.stringify({ ents: X.ents, t0: X.t0, t1: X.t1, userLength: X.userLength || null });
function scRedo() { const X = SCAN.rec && SCAN.rec.extr; if (!X || !SCAN.redo || !SCAN.redo.length) return; const o = JSON.parse(SCAN.redo.pop()); SCAN.redoing = true; scKeep(); SCAN.redoing = false; X.ents = o.ents; X.t0 = o.t0; X.t1 = o.t1; X.userLength = o.userLength || undefined; SCAN.sel = null; scUser('redo', {}); scUndoBtn(); scBodyRedraw(); }
function c9RedoBtn(u) { let b = $('scRedo'); if (!b) { b = document.createElement('button'); b.id = 'scRedo'; b.title = 'Bring back what Undo took away (Ctrl+Y)'; b.style.cssText = 'margin-left:6px;padding:2px 10px'; b.onclick = scRedo; u.after(b); } const n = SCAN.redo ? SCAN.redo.length : 0; b.disabled = !n; b.style.display = u.style.display; b.textContent = n ? `↷ Redo (${n})` : '↷ Redo'; }
/* ── the pick: one, or many with Shift ── */
function c9Pick(sel, ev, quiet) {
  const has = sel && c9Sel(sel.type, sel.i, sel.end);
  if (ev && ev.shiftKey) { if (sel && !has) C9.sels.push(sel); else if (!sel) return; }
  else if (!sel) { if (!C9.sels.length && !C9.sec) return; C9.sels = []; C9.sec = null; }
  else if (has) C9.sels = C9.sels.filter(q => !c9Same(q, sel.type, sel.i, sel.end));
  else C9.sels = [sel];
  const last = C9.sels[C9.sels.length - 1] || null; SCAN.sel = last ? { type: last.type, i: last.i, end: last.end } : null; if (last && SCAN.tab !== 'quant') SCAN.tab = 'edit'; if (!quiet) scBodyRedraw();
}
function c9PickedFlat() { const X = c9X(); if (!X) return null; const f = C9.sels.filter(q => q.type === 'face' && X.ents[q.i] && X.ents[q.i].t === 'line').map(q => q.i); return f.length === 0 ? null : f.length === 1 ? f[0] : f; }
function c9DeletePicked() { const X = c9X(); if (!X) return; const faces = C9.sels.filter(q => q.type === 'face').map(q => q.i).sort((a, b) => b - a), edges = C9.sels.filter(q => q.type === 'edge').map(q => q.i).sort((a, b) => b - a); for (const i of faces) scBodyDelete(i); if (!faces.length) for (const i of edges) scBodyMerge(i); }
/* after a tool of Quantise: whatever now lies on its grid is marked as held to it */
function c9AfterQuant() { const X = c9X(); if (!X) return; scBodyBuild(X); const st = c9Step(); for (const e of X.ents) { scSpan(e); if (e.t === 'line' ? c9Grid(scElLen(e), st) : c9Grid(e.r, st)) e.ql = st; }
  for (const c of X.corners) { const A = X.ents[c.i], B = X.ents[c.j]; if (c.gap > 0.05 || A.t !== 'line' || B.t !== 'line') continue; const th = c9Ang(X, c); A.qa = c9AngOk('90', th) ? '90' : c9AngOk('45', th) ? '45' : c9AngOk('deg', th) ? 'deg' : A.qa; } }

/* ── an edge of a face at an end of the body (a 'rim') ── */
function c9RimPts(X, i, end) { const e = X.ents[i]; scSpan(e); const pts = e.t === 'line' ? [e.p0, e.p1] : scArcPts(e, 24), t = end ? X.t1 : X.t0; return pts.map(p => c9P3(X, p, t)); }
/* a line of a given thickness on the screen (the wide lines of three.js, loaded apart; a hairline until they have come) */
let C9_FAT = null; Promise.all([import('three/addons/lines/Line2.js'), import('three/addons/lines/LineMaterial.js'), import('three/addons/lines/LineGeometry.js')]).then(([a, b, c]) => { C9_FAT = { Line2: a.Line2, LineMaterial: b.LineMaterial, LineGeometry: c.LineGeometry }; if (c9X() && C9.sels.some(q => q.type === 'rim')) scBodyRedraw(); }).catch(() => {});
function c9FatLine(pts, col, px) { let o; if (C9_FAT) { const g = new C9_FAT.LineGeometry(); g.setPositions(pts.flat()); const m = new C9_FAT.LineMaterial({ color: col, linewidth: px, depthTest: false, transparent: true }); m.resolution.set(canvas.clientWidth, canvas.clientHeight); o = new C9_FAT.Line2(g, m); o.computeLineDistances(); o.userData.fat = true; }
  else { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pts.flat(), 3)); o = new THREE.Line(g, new THREE.LineBasicMaterial({ color: col, depthTest: false, transparent: true })); } o.renderOrder = 19; return o; }
function c9RimAt(ev, tol = 9) { const X = c9X(); if (!X || !SCAN.reconGroup) return null; const r = canvas.getBoundingClientRect(); SCAN.group.updateMatrixWorld(true); const scr = q => c9Scr(new THREE.Vector3(...q).applyMatrix4(SCAN.reconGroup.matrixWorld), r); let best = null, bd = tol;
  X.ents.forEach((e, i) => { for (const end of [0, 1]) { const pts = c9RimPts(X, i, end).map(scr); for (let q = 1; q < pts.length; q++) { const a = pts[q - 1], b = pts[q], vx = b[0] - a[0], vy = b[1] - a[1], L2 = vx * vx + vy * vy || 1, t = Math.max(0, Math.min(1, ((ev.clientX - a[0]) * vx + (ev.clientY - a[1]) * vy) / L2)), d = Math.hypot(ev.clientX - a[0] - t * vx, ev.clientY - a[1] - t * vy) - (c9Sel('face', i) ? 2 : 0); if (d < bd) { bd = d; best = { i, end }; } } } }); return best; }
/* what the Edit panel says about a picked rim */
function c9RimHtml(X, S, box) { if (!S || S.type !== 'rim' || !X.ents[S.i]) return ''; const e = X.ents[S.i]; scSpan(e); const A = 'XYZ'[X.k], cs = [X.corners.find(c => c.j === S.i), X.corners.find(c => c.i === S.i)];
  return box('#e0b000', `<b>Edge</b> where a ${e.t === 'line' ? 'flat' : 'round'} face meets the ${S.end ? 'far' : 'near'} end of the body (${A} = ${c9Fmt(S.end ? X.t1 : X.t0, 3)})<br>its length: <b>${c9Fmt(scElLen(e), 3)} mm</b>${e.t !== 'line' ? `, R ${c9Fmt(e.r, 3)} mm` : ''}<br>the end stands square to ${A}: the body is pushed along it<div class="row">${cs.map((c, n) => c ? `<button class="c9rimgo" data-edge="${c.i}" data-at="${S.end ? 1 : 0}" data-side="${n ? 'a' : 'b'}">Section at its ${n ? 'second' : 'first'} corner</button>` : '').join('')}</div>`); }
addEventListener('click', e => { const b = e.target.closest && e.target.closest('.c9rimgo'); if (b) c9Run('openSection', { edge: +b.dataset.edge, at: +b.dataset.at, side: b.dataset.side }); });
/* ── the section in the scene ── */
function c9Sec(X) { const s = C9.sec; if (!s || !X || !X.corners) return null; const c = X.corners.find(q => X.ents[q.i].id === s.ida && X.ents[q.j].id === s.idb); if (!c) { C9.sec = null; return null; } const A = X.ents[c.i], B = X.ents[c.j];
  if (s.side === 'a' && A.t !== 'line' && B.t === 'line') s.side = 'b'; else if (s.side === 'b' && B.t !== 'line' && A.t === 'line') s.side = 'a'; s.level = Math.max(X.t0, Math.min(X.t1, s.level));
  const q = c9Sides(X, c, s.side); return Object.assign(q, { c, side: s.side, level: s.level, P: [...A[c.ka]], da: scElDir(q.act, q.ka), dq: scElDir(q.oth, q.ko) }); }
function c9Disc() { const cv = document.createElement('canvas'); cv.width = cv.height = 32; const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.beginPath(); g.arc(16, 16, 14, 0, 7); g.fill(); const t = new THREE.CanvasTexture(cv); return t; }
function c9Scene(add, X, vw) {
  if (vw.extrLines) for (const [V, round] of [[X.vSq, false], [X.vCi, true]]) { if (!V || !V.pos.length) continue; const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(V.pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(V.col, 3));
    const m = new THREE.PointsMaterial({ vertexColors: true, size: round ? 18 : 16, sizeAttenuation: false, depthTest: false, transparent: true }); if (round) { m.map = c9Disc(); m.alphaTest = 0.5; } const p = new THREE.Points(g, m); p.renderOrder = 6; add(p); SCAN.bodyParts.push(p); }
  for (const q of C9.sels) if (q.type === 'rim' && X.ents[q.i]) { const o = c9FatLine(c9RimPts(X, q.i, q.end), 0xffc400, 5); add(o); SCAN.bodyParts.push(o); }
  C9.G = null; const s = c9Sec(X); if (!s) return; const k = X.k, [i0, j0] = [0, 1, 2].filter(q => q !== k), at = pt => c9P3(X, pt, s.level);
  const line = (pts, col, op = 1, top = false) => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pts.flat(), 3)); const o = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: col, transparent: op < 1 || top, opacity: op, depthTest: !top })); o.renderOrder = top ? 20 : 4; return o; };
  /* the plane: as large as the outline of the part with a margin; see-through */
  let lo = [Infinity, Infinity], hi = [-Infinity, -Infinity]; for (const p of X.poly) { lo = [Math.min(lo[0], p[0]), Math.min(lo[1], p[1])]; hi = [Math.max(hi[0], p[0]), Math.max(hi[1], p[1])]; } const dg = Math.hypot(hi[0] - lo[0], hi[1] - lo[1]), mg = 0.06 * dg, hf = Math.max(12, 0.3 * dg); lo = [Math.max(lo[0] - mg, s.P[0] - hf), Math.max(lo[1] - mg, s.P[1] - hf)]; hi = [Math.min(hi[0] + mg, s.P[0] + hf), Math.min(hi[1] + mg, s.P[1] + hf)];       // about the corner, no further than the part reaches
  { const q = [[lo[0], lo[1]], [hi[0], lo[1]], [hi[0], hi[1]], [lo[0], hi[1]]].map(at), g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute([...q[0], ...q[1], ...q[2], ...q[0], ...q[2], ...q[3]], 3)); const pm = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0x3f8fe0, transparent: true, opacity: 0.13, side: THREE.DoubleSide, depthWrite: false })); pm.renderOrder = 3; add(pm); add(line([[q[0], q[1]], [q[1], q[2]], [q[2], q[3]], [q[3], q[0]]].flat(), 0x3f8fe0, 0.5)); }
  /* the part cut by the plane, faint; the profile of the scan too if asked for */
  { const seg = []; for (let i = 0; i < X.poly.length; i++) seg.push(at(X.poly[i]), at(X.poly[(i + 1) % X.poly.length])); add(line(seg, 0x1c2f4a, 0.45, true)); }
  if (C9.showMeas) { const seg = []; for (const m of X.meas) { scSpan(m); const pts = m.t === 'line' ? [m.p0, m.p1] : scArcPts(m, 16); for (let i = 1; i < pts.length; i++) seg.push(at(pts[i - 1]), at(pts[i])); } add(line(seg, 0xc0308c, 0.9, true)); }
  /* the manipulator: drawn in pixels about the corner, in the plane; its size on the screen is kept by c9Frame.
     Its parts are bands and discs, not hairlines, so that they can be seen and caught. */
  const G = new THREE.Group(); G.position.set(...at(s.P)); const L = (u, v) => { const q = [0, 0, 0]; q[i0] = u; q[j0] = v; return q; }, seg = (a, b) => [L(...a), L(...b)], da = s.da, dq = s.dq, n = [-da[1], da[0]], mul = (d, r) => [d[0] * r, d[1] * r], addv = (a, b) => [a[0] + b[0], a[1] + b[1]], PX = C9_PX;
  const flat = (tris, col, op = 1) => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(tris.flatMap(p => L(p[0], p[1])), 3)); const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide, depthTest: false, transparent: true, opacity: op })); m.renderOrder = 21; return m; };
  const band = (pts, w, col, op = 1) => { const t = []; for (let i = 1; i < pts.length; i++) { const a = pts[i - 1], b = pts[i], d = [b[0] - a[0], b[1] - a[1]], l = Math.hypot(d[0], d[1]) || 1, o = [-d[1] / l * w / 2, d[0] / l * w / 2]; t.push(addv(a, o), addv(b, o), addv(b, mul(o, -1)), addv(a, o), addv(b, mul(o, -1)), addv(a, mul(o, -1))); } return flat(t, col, op); };
  const disc = (c, r, col) => { const t = []; for (let i = 0; i < 24; i++) t.push(c, [c[0] + r * Math.cos(i * Math.PI / 12), c[1] + r * Math.sin(i * Math.PI / 12)], [c[0] + r * Math.cos((i + 1) * Math.PI / 12), c[1] + r * Math.sin((i + 1) * Math.PI / 12)]); return flat(t, col); };
  const head = (tip, dir, col) => { const b = addv(tip, mul(dir, -PX.head)), o = [-dir[1] * PX.head * 0.55, dir[0] * PX.head * 0.55]; return flat([tip, addv(b, o), addv(b, mul(o, -1))], col); };
  G.add(line([...seg([-PX.axis, 0], [PX.axis, 0]), ...seg([0, -PX.axis], [0, PX.axis])], 0x66788f, 0.6, true));              // the axes of the part through the corner
  G.add(band([[0, 0], mul(dq, PX.ray)], 2.5, 0x1c2f4a)); if (s.act.t === 'line') G.add(band([[0, 0], mul(da, PX.ray)], 3, 0xf08a00));
  { const a0 = Math.atan2(dq[1], dq[0]), sg = c9Cross(dq, da) >= 0 ? 1 : -1, th = Math.acos(Math.max(-1, Math.min(1, da[0] * dq[0] + da[1] * dq[1]))), pts = []; for (let i = 0; i <= 24; i++) pts.push([PX.arc * Math.cos(a0 + sg * th * i / 24), PX.arc * Math.sin(a0 + sg * th * i / 24)]); G.add(band(pts, 2, 0x1c2f4a, 0.85)); }
  const H = { rot: null, mov: null };
  if (s.act.t === 'line') { const a0 = Math.atan2(da[1], da[0]), R0 = PX.rot, w = PX.rotHalf, pts = []; for (let i = 0; i <= 16; i++) { const u = a0 - w + 2 * w * i / 16; pts.push([R0 * Math.cos(u), R0 * Math.sin(u)]); }
    G.add(band(pts, 4.5, 0xf08a00)); for (const e of [-1, 1]) { const u = a0 + e * w; G.add(head([R0 * Math.cos(u + e * 0.07), R0 * Math.sin(u + e * 0.07)], [-Math.sin(u) * e, Math.cos(u) * e], 0xf08a00)); }
    G.add(disc(mul(da, R0), PX.knobRot, 0xf08a00)); G.add(disc(mul(da, R0), PX.knobRot - 4, 0xffffff)); H.rot = mul(da, R0);
    const M = mul(da, PX.mov), a = addv(M, mul(n, PX.movHalf)), b = addv(M, mul(n, -PX.movHalf)); G.add(band([a, b], 4.5, 0x00a08a)); G.add(head(addv(a, mul(n, PX.head * 0.6)), n, 0x00a08a)); G.add(head(addv(b, mul(n, -PX.head * 0.6)), mul(n, -1), 0x00a08a));
    G.add(disc(M, PX.knobMov, 0x00a08a)); G.add(disc(M, PX.knobMov - 4, 0xffffff)); H.mov = M; H.movEnds = [a, b]; }
  G.userData = { H, L, s }; add(G); C9.G = G; c9Frame();
}
function c9Wpp(world) { const f = new THREE.Vector3(); camera.getWorldDirection(f); const d = world.clone().sub(camera.position).dot(f); return 2 * Math.max(1e-6, d) * Math.tan(camera.fov * Math.PI / 360) / Math.max(1, canvas.clientHeight); }
const c9Scr = (v, r) => { const q = v.clone().project(camera); return [r.left + (q.x + 1) / 2 * r.width, r.top + (1 - q.y) / 2 * r.height]; };
/* every frame: the manipulator keeps its size on the screen, the boxes with the numbers follow the corner */
function c9Frame() {
  for (const o of SCAN.bodyObjs || []) if (o.userData.fat) o.material.resolution.set(canvas.clientWidth, canvas.clientHeight);
  const ov = C9.ov, G = C9.G, X = c9X(); if (!G || !G.parent || !X || !C9.sec || DESK !== 'scan') { if (ov) ov.style.display = 'none'; return; }
  const R = SCAN.reconGroup; R.updateMatrixWorld(true); const P = new THREE.Vector3(...G.position.toArray()).applyMatrix4(R.matrixWorld), sc = R.matrixWorld.getMaxScaleOnAxis() || 1; G.scale.setScalar(c9Wpp(P) / sc); G.updateMatrixWorld(true);
  if (!ov) return; ov.style.display = ''; const r = canvas.getBoundingClientRect(), pr = ov.parentElement.getBoundingClientRect(), at = l => c9Scr(new THREE.Vector3(...l).applyMatrix4(G.matrixWorld), r), { L, s } = G.userData, p = at([0, 0, 0]);
  const dir = d => { const q = at(L(d[0] * 100, d[1] * 100)), v = [q[0] - p[0], q[1] - p[1]], l = Math.hypot(v[0], v[1]) || 1; return [v[0] / l, v[1] / l]; }, sa = dir(s.da), sq = dir(s.dq);
  const place = (el, x, y) => { const w = el.offsetWidth, h = el.offsetHeight; x = Math.max(r.left + 4, Math.min(r.right - w - 4, x)); y = Math.max(r.top + 4, Math.min(r.bottom - h - 4, y)); el.style.left = (x - pr.left) + 'px'; el.style.top = (y - pr.top) + 'px'; };
  /* the middle of a box is put `gap` pixels beyond its own edge along `v` from the point (x, y): however it is turned, it does not lie on what is drawn there */
  const used = [], rect = el => { const b = el.getBoundingClientRect(); return [b.left - 4, b.top - 4, b.right + 4, b.bottom + 4]; }, hits = b => used.some(u => b[0] < u[2] && b[2] > u[0] && b[1] < u[3] && b[3] > u[1]);
  for (const el of [C9.el.A, C9.el.La, C9.el.Lb]) { const pin = C9.pin[el.id]; el.classList.toggle('pinned', !!pin); if (pin) { place(el, r.left + pin.x, r.top + pin.y); used.push(rect(el)); } }
  const put = (el, x, y, v, gap) => { if (C9.pin[el.id]) return; const w = el.offsetWidth, h = el.offsetHeight; let far = gap + Math.abs(v[0]) * w / 2 + Math.abs(v[1]) * h / 2;
    for (let i = 0; i < 14; i++) { place(el, x + v[0] * far - w / 2, y + v[1] * far - h / 2); if (!hits(rect(el))) break; far += 18; }                                   // one box does not lie on another: it steps further out
    used.push(rect(el)); };
  let bis = [sa[0] + sq[0], sa[1] + sq[1]]; const bl = Math.hypot(bis[0], bis[1]); bis = bl > 0.05 ? [bis[0] / bl, bis[1] / bl] : [-sa[1], sa[0]];
  put(C9.el.A, p[0], p[1], [-bis[0], -bis[1]], C9_PX.arc + 22);
  const side = (el, d, o, gap) => { let n = [-d[1], d[0]]; if (n[0] * o[0] + n[1] * o[1] > 0) n = [-n[0], -n[1]]; put(el, p[0] + d[0] * C9_PX.mov, p[1] + d[1] * C9_PX.mov, n, gap); };
  side(s.side === 'a' ? C9.el.La : C9.el.Lb, sa, sq, C9_PX.movHalf + C9_PX.head + 14); side(s.side === 'a' ? C9.el.Lb : C9.el.La, sq, sa, 22);
  const [i0, j0] = [0, 1, 2].filter(q => q !== X.k); const ax = (el, u, v, t) => { const q = at(L(u, v)); el.textContent = t; el.style.left = (q[0] - pr.left - 4) + 'px'; el.style.top = (q[1] - pr.top - 8) + 'px'; }; ax(C9.el.ax0, C9_PX.axis + 10, 0, 'XYZ'[i0]); ax(C9.el.ax1, 0, C9_PX.axis + 10, 'XYZ'[j0]);
}
/* the boxes with the numbers: made once, filled after every change */
function c9Overlay() {
  if (C9.ov) return; const st = document.createElement('style'); st.textContent = `#c9ov{position:absolute;left:0;top:0;width:0;height:0;z-index:6;font:12px system-ui,sans-serif;color:#14202e}
#c9ov .c9b{position:absolute;cursor:move;user-select:none;background:rgba(255,255,255,.94);border:1px solid #9fb0c2;border-radius:6px;padding:4px 6px;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,.18)}
#c9ov .c9b.act{border:2px solid #f08a00} #c9ov .c9home{display:none} #c9ov .c9b.pinned .c9home{display:inline-block} #c9ov .c9b input,#c9ov .c9b button,#c9ov .c9b label{cursor:auto} #c9ov input[type=number]{width:74px;font:600 13px system-ui,sans-serif;padding:1px 3px} #c9ov button{font:12px system-ui,sans-serif;padding:1px 6px;margin-left:2px;border:1px solid #9fb0c2;border-radius:4px;background:#fff;cursor:pointer}
#c9ov button.on{background:#14306a;color:#fff;border-color:#14306a} #c9ov .c9s{color:#5a6b7d;font-size:11px;margin-top:2px} #c9ov .c9m{color:#b3261e;font-size:11px;max-width:300px;white-space:normal;margin-top:2px}
#c9ov .c9ax{position:absolute;color:#52647a;font-weight:600;pointer-events:none} #c9ov label{margin-left:4px;cursor:pointer} #c9ov .c9who{font-weight:600;margin-right:4px}
@keyframes c9bl{0%,100%{box-shadow:none}50%{box-shadow:0 0 0 3px #e2362f;background:#ffd9d6}} #c9ov .c9blink{animation:c9bl .3s 4}`; document.head.appendChild(st);
  const ov = document.createElement('div'); ov.id = 'c9ov'; const host = canvas.parentElement; if (getComputedStyle(host).position === 'static') host.style.position = 'relative'; host.appendChild(ov);
  const lenBox = k => `<div class="c9b c9l" id="c9L${k}"><span class="c9who"></span><span class="c9len"><input type="number" step="0.1" data-len="${k}"> mm <label title="Hold this length to whole steps of the size grid"><input type="checkbox" data-ql="${k}"> <span class="c9st"></span></label></span><button data-act="${k}" title="Put the manipulator on this face">◎</button><button class="c9home" title="Back to its own place beside the corner">⌂</button><div class="c9s"></div></div>`;
  ov.innerHTML = `<div class="c9b" id="c9A"><b>∠</b> <input type="number" step="0.1" id="c9Ang">° <span id="c9qa"><button data-m="90" title="Hold the angle square">90°</button><button data-m="45" title="Hold the angle to multiples of 45°">45°</button><button data-m="deg" title="Hold the angle to whole degrees">1°</button></span><button id="c9meas" title="Put the active face back where the scan had it">↺ scan</button><button class="c9home" title="Back to its own place beside the corner">⌂</button><button id="c9x" title="Close (Esc)">×</button><div class="c9s" id="c9sA"></div><label style="margin-left:0"><input type="checkbox" id="c9sm"> profile of the scan</label><div class="c9m" id="c9msg"></div></div>${lenBox('a')}${lenBox('b')}<span class="c9ax" id="c9ax0"></span><span class="c9ax" id="c9ax1"></span>`;
  C9.ov = ov; C9.el = { A: ov.querySelector('#c9A'), La: ov.querySelector('#c9La'), Lb: ov.querySelector('#c9Lb'), ax0: ov.querySelector('#c9ax0'), ax1: ov.querySelector('#c9ax1') };
  const edge = () => { const X = c9X(), s = c9Sec(X); return s ? { X, s, edge: s.c.i } : null; };
  ov.addEventListener('wheel', e => e.stopPropagation());
  /* a box is taken by its ground (not by a field or a button) and put where the person wants it; it then stays there */
  ov.addEventListener('pointerdown', e => { e.stopPropagation(); const box = e.target.closest('.c9b'); if (!box || e.button !== 0 || e.target.closest('input,button,label')) return; e.preventDefault(); const r = canvas.getBoundingClientRect(), b = box.getBoundingClientRect(), off = [e.clientX - b.left, e.clientY - b.top];
    const move = ev => { C9.pin[box.id] = { x: ev.clientX - off[0] - r.left, y: ev.clientY - off[1] - r.top }; c9Frame(); }, up = () => { removeEventListener('pointermove', move, true); removeEventListener('pointerup', up, true); }; addEventListener('pointermove', move, true); addEventListener('pointerup', up, true); });
  ov.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') e.target.blur(); if (e.key === 'Escape') { c9Fill(); e.target.blur(); } });
  ov.addEventListener('change', e => { const q = edge(), t = e.target; if (!q) return; const other = q.s.side === 'a' ? 'b' : 'a';
    if (t.id === 'c9Ang') c9Run('setAngle', { edge: q.edge, side: q.s.side, angle: +t.value });
    else if (t.dataset.len) c9Run('setLength', { edge: q.edge, side: t.dataset.len, length: +t.value });
    else if (t.dataset.ql) c9Run('quantSize', { edge: q.edge, side: t.dataset.ql, on: t.checked });
    else if (t.id === 'c9sm') { C9.showMeas = t.checked; scBodyRedraw(); } void other; });
  ov.addEventListener('click', e => { const q = edge(), t = e.target.closest('button'); if (!q || !t) return; if (t.classList.contains('c9home')) { delete C9.pin[t.closest('.c9b').id]; c9Frame(); return; }
    if (t.dataset.m) c9Run('quantAngle', { edge: q.edge, side: q.s.side, mode: q.s.A.qa === t.dataset.m ? 'off' : t.dataset.m });
    else if (t.dataset.act) c9Run('activeSide', { side: t.dataset.act }); else if (t.id === 'c9meas') c9Run('toMeasured', { edge: q.edge, side: q.s.side }); else if (t.id === 'c9x') c9Run('closeSection'); });
}
function c9Fill() {
  c9Overlay(); const X = c9X(), s = c9Sec(X), ov = C9.ov; if (!s) { ov.style.display = 'none'; return; } const E = C9.el, m = c9Measured(X, s.c), th = c9Ang(X, s.c), now = performance.now(), blink = key => C9.drops.some(d => d.key === key && now - d.t < 1500) || (C9.blink && C9.blink.key === key && now - C9.blink.t < 1500), foc = document.activeElement;
  const ang = ov.querySelector('#c9Ang'); if (foc !== ang) ang.value = c9Fmt(th, 3); ang.disabled = s.act.t !== 'line';
  ov.querySelectorAll('#c9qa button').forEach(b => { b.classList.toggle('on', s.A.qa === b.dataset.m); b.classList.toggle('c9blink', blink('qa' + s.A.id)); });
  ov.querySelector('#c9sA').textContent = (m.angle === null ? 'the scan has no angle here' : `scan ${c9Fmt(m.angle, 2)}°` + (Math.abs(m.angle - th) > 5e-3 ? ` · changed by ${c9Fmt(th - m.angle, 2)}°` : '')) + (s.c.gap > 0.05 ? ` · the faces do not meet: a gap of ${c9Fmt(s.c.gap, 3)} mm` : '');
  ov.querySelector('#c9msg').textContent = C9.msg || ''; ov.querySelector('#c9sm').checked = C9.showMeas; ov.querySelector('#c9meas').disabled = s.act.t !== 'line';
  for (const k of ['a', 'b']) { const e = k === 'a' ? s.A : s.B, box = k === 'a' ? E.La : E.Lb, inp = box.querySelector('input[type=number]'), cb = box.querySelector('input[type=checkbox]'), ml = k === 'a' ? m.lenA : m.lenB; scSpan(e); box.classList.toggle('act', s.side === k);
    box.querySelector('.c9who').textContent = s.side === k ? 'active' : 'stands'; box.querySelector('.c9len').style.display = e.t === 'line' ? '' : 'none'; box.querySelector('[data-act]').style.display = e.t === 'line' && s.side !== k ? '' : 'none';
    if (e.t === 'line') { if (foc !== inp) inp.value = c9Fmt(scElLen(e), 3); cb.checked = !!e.ql; box.querySelector('.c9st').textContent = `${c9Fmt(e.ql || c9Step(), 3)} mm`; cb.parentElement.classList.toggle('c9blink', blink('ql' + e.id)); box.querySelector('.c9s').textContent = ml === null ? '' : `scan ${c9Fmt(ml, 3)}`; }
    else box.querySelector('.c9s').textContent = `round, R ${c9Fmt(e.r, 3)} mm` + (e.guess ? ' (a guess)' : ''); }
  if (C9.drops.some(d => now - d.t < 1500) || (C9.blink && now - C9.blink.t < 1500)) { clearTimeout(C9.blinkT); C9.blinkT = setTimeout(c9Fill, 1600); }
  ov.style.display = ''; c9Frame();
}

/* ── the mouse: a right click opens the section; the handles of the manipulator are dragged; the wheel comes in on the picked edge ── */
function c9EdgeAt(ev, tol = 9) { const X = c9X(); if (!X || !SCAN.reconGroup) return null; const r = canvas.getBoundingClientRect(); SCAN.group.updateMatrixWorld(true); const scr = q => c9Scr(new THREE.Vector3(...q).applyMatrix4(SCAN.reconGroup.matrixWorld), r); let best = null, bd = tol;
  for (const c of X.corners) { const a = scr(c.a3), b = scr(c.b3), vx = b[0] - a[0], vy = b[1] - a[1], L2 = vx * vx + vy * vy || 1, t = Math.max(0, Math.min(1, ((ev.clientX - a[0]) * vx + (ev.clientY - a[1]) * vy) / L2)), d = Math.hypot(ev.clientX - a[0] - t * vx, ev.clientY - a[1] - t * vy); if (d < bd) { bd = d; best = { c, t }; } } return best; }
function c9Open(ev) { const h = c9EdgeAt(ev); if (!h) { const m = c9RimAt(ev); if (m) c9Run('select', { type: 'rim', i: m.i, end: m.end, add: !!ev.shiftKey }); return; } const X = c9X(), A = X.ents[h.c.i]; c9Run('openSection', { edge: h.c.i, at: +c9Fmt(h.t, 4), side: A.t === 'line' ? 'a' : 'b' }); }
function c9Close(quiet) { if (!C9.sec) return; C9.sec = null; C9.msg = ''; if (!quiet) scBodyRedraw(); }
/* where the pointer meets the plane of the section, in the coordinates of the profile */
function c9PlanePt(ev) { const X = c9X(), G = C9.G; if (!X || !G) return null; const R = SCAN.reconGroup, r = canvas.getBoundingClientRect(), rc = new THREE.Raycaster(); rc.setFromCamera(new THREE.Vector2((ev.clientX - r.left) / r.width * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1), camera);
  R.updateMatrixWorld(true); const inv = R.matrixWorld.clone().invert(), o = rc.ray.origin.clone().applyMatrix4(inv), d = rc.ray.direction.clone().transformDirection(inv), k = X.k, [i0, j0] = [0, 1, 2].filter(q => q !== k), dk = d.getComponent(k); if (Math.abs(dk) < 1e-9) return null; const t = (C9.sec.level - o.getComponent(k)) / dk; if (t <= 0) return null; const q = o.addScaledVector(d, t); return [q.getComponent(i0), q.getComponent(j0)]; }
function c9Hit(ev) { const G = C9.G; if (!G) return null; const r = canvas.getBoundingClientRect(), { H, L, s } = G.userData, at = p => c9Scr(new THREE.Vector3(...L(p[0], p[1])).applyMatrix4(G.matrixWorld), r), near = (p, tol) => { const q = at(p); return Math.hypot(q[0] - ev.clientX, q[1] - ev.clientY) <= tol; };
  const PX = C9_PX; if (H.rot && near(H.rot, PX.knobRot + 9)) return 'rot'; if (H.mov && (near(H.mov, PX.knobMov + 9) || H.movEnds.some(p => near(p, 14)))) return 'mov';
  if (H.rot) { const a0 = Math.atan2(s.da[1], s.da[0]); for (let i = -6; i <= 6; i++) if (near([PX.rot * Math.cos(a0 + i * PX.rotHalf / 6), PX.rot * Math.sin(a0 + i * PX.rotHalf / 6)], 11)) return 'rot'; }
  if (H.mov) for (let i = -4; i <= 4; i++) if (near([H.mov[0] - s.da[1] * PX.movHalf * i / 4, H.mov[1] + s.da[0] * PX.movHalf * i / 4], 10)) return 'mov';
  const seg = d => { const a = at([0, 0]), b = at([d[0] * PX.ray, d[1] * PX.ray]), vx = b[0] - a[0], vy = b[1] - a[1], L2 = vx * vx + vy * vy || 1, t = Math.max(0.15, Math.min(1, ((ev.clientX - a[0]) * vx + (ev.clientY - a[1]) * vy) / L2)); return Math.hypot(ev.clientX - a[0] - t * vx, ev.clientY - a[1] - t * vy) <= 7; };
  if (s.oth.t === 'line' && seg(s.dq)) return s.side === 'a' ? 'b' : 'a'; return null; }
function c9DragMove(ev) {
  const D = C9.drag, X = c9X(); if (!D || !X) return; const pt = c9PlanePt(ev); if (!pt) return; X.ents = JSON.parse(D.snap); scBodyBuild(X); const c = X.corners.find(q => X.ents[q.i].id === D.ids[0] && X.ents[q.j].id === D.ids[1]); if (!c) return; const s = c9Sides(X, c, D.side), A = X.ents[c.i]; let r = { ok: true }; C9.msg = '';
  if (D.kind === 'rot') { const P = s.act[s.ka], dq = scElDir(s.oth, s.ko), da = scElDir(s.act, s.ka), v = [pt[0] - P[0], pt[1] - P[1]], vl = Math.hypot(v[0], v[1]); if (vl < 1e-9) return; const sg = c9Cross(dq, da) >= 0 ? 1 : -1, v0 = [D.pt0[0] - P[0], D.pt0[1] - P[1]], turn = Math.atan2(c9Cross(v0, v), v0[0] * v[0] + v0[1] * v[1]) * 180 / Math.PI; let th = D.before.angle + sg * turn;
    const st = C9.q.aStep; if (A.qa === '90') { C9.msg = 'the angle is held square here: switch 90° off to turn the face'; C9.blink = { key: 'qa' + A.id, t: performance.now() }; r = { ok: false }; }
    else { if (A.qa === '45') th = Math.max(45, Math.min(135, Math.round(th / 45) * 45)); else if (A.qa === 'deg') th = Math.max(st, Math.min(180 - st, Math.round(th / st) * st)); else th = Math.max(0.5, Math.min(179.5, th)); r = c9SetAngle(X, c, D.side, th); D.value = th; } }
  else { const P0 = D.P0, da = scElDir(s.act, s.ka), n = [-da[1], da[0]]; let by = (pt[0] - D.pt0[0]) * n[0] + (pt[1] - D.pt0[1]) * n[1]; void P0;
    if (s.oth.t === 'line' && s.oth.ql) { const dq = scElDir(s.oth, s.ko), F = s.oth[s.ko === 'p0' ? 'p1' : 'p0'], P = s.act[s.ka], Q = [P[0] + n[0] * by, P[1] + n[1] * by], Pn = c9LineLine(Q, da, P, dq); if (Pn) { const len = (F[0] - Pn[0]) * dq[0] + (F[1] - Pn[1]) * dq[1], st = s.oth.ql, to = Math.max(st, Math.round(len / st) * st); r = c9SetLen(X, c, D.side === 'a' ? 'b' : 'a', to); D.value = to; D.cmd = 'setLength'; } }
    else { r = c9Shift(X, c, D.side, by); D.value = by; D.cmd = 'shift'; } }
  if (!r.ok) { X.ents = JSON.parse(D.last || D.snap); if (r.why) C9.msg = r.why; } else D.last = JSON.stringify(X.ents);
  scBodyBuild(X); scBodyDraw(SCAN.reconGroup, SCAN.rec, SCAN.view); c9Fill();
}
addEventListener('pointerdown', e => { if (e.target !== canvas || DESK !== 'scan' || e.button !== 0 || !C9.G || !C9.sec) return; const h = c9Hit(e); if (!h) return; e.stopPropagation(); e.preventDefault();
  if (h === 'a' || h === 'b') { c9Run('activeSide', { side: h }); return; } const X = c9X(), s = c9Sec(X); if (!s) return; scBodyBuild(X); const redo0 = [...(SCAN.redo || [])]; scKeep();
  C9.drag = { redo0, kind: h, side: s.side, ids: [s.A.id, s.B.id], snap: JSON.stringify(X.ents), pt0: c9PlanePt(e) || [...s.P], P0: [...s.P], before: c9State(X, s.c.i), cmd: h === 'rot' ? 'setAngle' : 'shift' }; canvas.style.cursor = 'grabbing'; }, true);
addEventListener('pointermove', e => { if (C9.drag) { e.stopPropagation(); const D = C9.drag; D.ev = e; if (!D.raf) D.raf = requestAnimationFrame(() => { D.raf = 0; if (C9.drag === D) c9DragMove(D.ev); }); return; } if (e.target === canvas && C9.G && C9.sec && DESK === 'scan' && !e.buttons) { const h = c9Hit(e); canvas.style.cursor = h === 'rot' || h === 'mov' ? 'grab' : h ? 'pointer' : ''; } }, true);
addEventListener('pointerup', e => { const D = C9.drag; if (!D) return; e.stopPropagation(); if (D.raf) { cancelAnimationFrame(D.raf); D.raf = 0; c9DragMove(D.ev); } C9.drag = null; canvas.style.cursor = ''; const X = c9X(); if (!X) return;
  if (JSON.stringify(X.ents) === D.snap) { SCAN.undo.pop(); SCAN.redo = D.redo0; scUndoBtn(); } else { scBodyBuild(X); const c = X.corners.find(q => X.ents[q.i].id === D.ids[0] && X.ents[q.j].id === D.ids[1]), args = { edge: c ? c.i : null, side: D.cmd === 'setLength' ? (D.side === 'a' ? 'b' : 'a') : D.side, by: 'the manipulator' }; args[D.cmd === 'setAngle' ? 'angle' : D.cmd === 'setLength' ? 'length' : 'by'] = +c9Fmt(D.value || 0, 6); c9Record(D.cmd, args, D.before, c ? c9State(X, c.i) : null, true); }
  scBodyRedraw(); }, true);
canvas.addEventListener('contextmenu', e => { if (DESK === 'scan') e.preventDefault(); });
/* the wheel, while an edge is picked or its section is open: the edge is brought to the middle of the screen and stays there as the view comes closer */
addEventListener('wheel', e => { if (e.target !== canvas || DESK !== 'scan') return; const X = c9X(); if (!X || !SCAN.reconGroup || !X.corners) return; let p = null; const s = c9Sec(X); if (s) p = c9P3(X, s.P, s.level); else { const S = SCAN.sel, c = S && S.type === 'edge' ? c9Corner(X, S.i) : null; if (c) p = c.a3.map((v, i) => (v + c.b3[i]) / 2); else if (S && S.type === 'rim' && X.ents[S.i]) { const q = c9RimPts(X, S.i, S.end); p = q[q.length >> 1].map((v, i) => q.length === 2 ? (q[0][i] + q[1][i]) / 2 : v); } } if (!p) return;
  SCAN.group.updateMatrixWorld(true); const d = new THREE.Vector3(...p).applyMatrix4(SCAN.reconGroup.matrixWorld).sub(controls.target); if (d.lengthSq() < 1e-12) return; camera.position.add(d); controls.target.add(d); }, { capture: true, passive: true });

/* ── experience: every command with what was measured, what stood and what stands; kept in a file of its own ── */
function c9ExpSave() { const all = [...C9.expLoaded, ...C9.exp]; download('experience.json', JSON.stringify({ format: 'snark-scan experience', version: 1, note: 'One record for every command: what the scan measured, what the program had, what the person set. Later sessions add to it.', cases: all }, null, 1), 'application/json'); }
function c9ExpLoad() { const f = document.createElement('input'); f.type = 'file'; f.accept = '.json'; f.onchange = async () => { try { const o = JSON.parse(await f.files[0].text()); if (o.format !== 'snark-scan experience' || !Array.isArray(o.cases)) throw new Error('this is not an experience file of SnarkScan'); C9.expLoaded = C9.expLoaded.concat(o.cases); scSay(`${o.cases.length} records of experience added (${C9.expLoaded.length + C9.exp.length} in all)`); scLeft(); } catch (err) { alert(err.message); } }; f.click(); }
window.__c9 = { run: c9Run, list: () => Object.entries(C9_CMDS).map(([name, d]) => ({ name, args: d.args, does: d.does })), state: C9, corner: e => { const X = c9X(); return X ? c9State(X, e) : null; }, measured: e => { const X = c9X(), c = X && c9Corner(X, e); return c ? c9Measured(X, c) : null; }, hit: c9Hit, frame: c9Frame,
  /* for the tests: where things are on the screen */
  pix: () => { const t = c9Test(); if (!t) return null; const p = t.at([0, 0]), q = t.at([t.s.da[0] * C9_PX.rot, t.s.da[1] * C9_PX.rot]); return { p, arm: Math.hypot(q[0] - p[0], q[1] - p[1]), wpp: c9Wpp(new THREE.Vector3().setFromMatrixPosition(C9.G.matrixWorld)) }; },
  handle: k => { const t = c9Test(); return t.at(k === 'rot' ? t.H.rot : t.H.mov); },
  rimPoint: (i, end, t) => { const X = c9X(), q = c9RimPts(X, i, end), r = canvas.getBoundingClientRect(), a = q[0], b = q[q.length - 1]; SCAN.group.updateMatrixWorld(true); return c9Scr(new THREE.Vector3(...a.map((v, k) => v + (b[k] - v) * t)).applyMatrix4(SCAN.reconGroup.matrixWorld), r); },
  marks: () => (SCAN.bodyObjs || []).filter(o => o.isPoints).map(o => o.material.size), fat: () => !!C9_FAT,
  ends: () => { const t = c9Test(); return t.H.movEnds ? t.H.movEnds.map(p => t.at(p)) : []; },
  handleDir: () => { const t = c9Test(), n = [-t.s.da[1], t.s.da[0]], a = t.at([0, 0]), b = t.at([n[0] * 60, n[1] * 60]), l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; return [(b[0] - a[0]) / l, (b[1] - a[1]) / l]; },
  edgePoint: (E, t) => { const X = c9X(), c = c9Corner(X, E), r = canvas.getBoundingClientRect(); SCAN.group.updateMatrixWorld(true); return c9Scr(new THREE.Vector3(...c.a3.map((v, i) => v + (c.b3[i] - v) * t)).applyMatrix4(SCAN.reconGroup.matrixWorld), r); } };
function c9Test() { const G = C9.G; if (!G) return null; G.updateMatrixWorld(true); const r = canvas.getBoundingClientRect(), { H, L, s } = G.userData; return { at: p => c9Scr(new THREE.Vector3(...L(p[0], p[1])).applyMatrix4(G.matrixWorld), r), H, s }; }
