#!/usr/bin/env python3
"""SnarkScan_09 = SnarkScan_08 + correct09.js + the changes listed here.
Every change is an exact replacement of text that must be found exactly once (or the stated number of times),
so a change of the page underneath cannot pass unnoticed. SnarkScan_08.html is only read.
usage: python3 build09.py <SnarkScan_08.html> <correct09.js> <SnarkScan_09.html>"""
import sys

src, mod, out = sys.argv[1:4]
s = open(src, encoding='utf-8').read()
js = open(mod, encoding='utf-8').read()
done = []


def rep(old, new, count=1, what=''):
    global s
    n = s.count(old)
    assert n == count, f'{what or old[:60]!r}: found {n} times, expected {count}'
    s = s.replace(old, new)
    done.append(what or old[:50])


# 0. the name
rep('SnarkScan_08', 'SnarkScan_09', s.count('SnarkScan_08'), 'name')

# 1. scBodyBuild: numbers and the measured copy first; colours by kind and state; many picked; marks at the corners
rep("function scBodyBuild(X) {\n  const k = X.k,", "function scBodyBuild(X) {\n  c9Sync(X); const k = X.k,", what='build: sync')
rep("sel = S && S.type === 'face' && S.i === ei, cc = sel ? GREEN : scMix(u, [0.62, 0.74, 0.95], [0.97, 0.55, 0.5]), kc = sel ? [0.05, 0.5, 0.15] : scMix(u, [0.08, 0.25, 0.85], [0.9, 0.05, 0.05]);",
    "sel = c9Sel('face', ei), cc = sel ? GREEN : scMix(u, [0.62, 0.74, 0.95], [0.97, 0.55, 0.5]), kc = sel ? [0.05, 0.5, 0.15] : c9SideCol(e);", what='build: face colours')
rep("sel = S && S.type === 'edge' && S.i === i, u = Math.max(scUnsure(A), scUnsure(B)), kc = sel ? YELLOW : scMix(u, [0.08, 0.25, 0.85], [0.9, 0.05, 0.05]);",
    "sel = c9Sel('edge', i), kc = c9EdgeKc(A, B, bd, ka, kb, sel);", what='build: edge colours')
rep("area: Math.abs(area) / 2, centre: cen, poly });\n}", "area: Math.abs(area) / 2, centre: cen, poly }); c9Vertices(X);\n}", what='build: vertices')

# 2. the body is drawn by a function of its own, so that a change of the body does not draw the whole scan again
a = s.index("    SCAN.bodyMesh = null; SCAN.bodyParts = []; if (rec.extr) { const X = rec.extr;")
endmark = "      if (SCAN.mix !== undefined && SCAN.mix !== 0.5) scMixView(SCAN.mix); }\n"
b = s.index(endmark, a)
assert s.count(endmark) == 1
block = s[a:b]
assert block.count('R.add(') == 4, block.count('R.add(')
block = block.replace('R.add(', 'add(')
fn = ("/* the rebuilt body in the scene. It is drawn apart from the scan: after a change of the body only this is drawn again */\n"
      "function scBodyDraw(R, rec, vw) {\n"
      "  for (const o of SCAN.bodyObjs || []) { if (o.parent) o.parent.remove(o); o.traverse(q => { q.geometry?.dispose(); const m = q.material; if (m) for (const x of Array.isArray(m) ? m : [m]) { x.map?.dispose(); x.dispose(); } }); }\n"
      "  SCAN.bodyObjs = []; const add = o => { R.add(o); SCAN.bodyObjs.push(o); };\n"
      + block +
      "      c9Scene(add, X, vw); if (SCAN.mix !== undefined && SCAN.mix !== 0.5) scMixView(SCAN.mix); }\n"
      "}\n")
s = s[:a] + "    scBodyDraw(R, rec, vw);\n" + s[b + len(endmark):]
rep("function scanDraw() {\n", fn + "function scanDraw() {\n", what='draw: scBodyDraw')
rep("const scBodyRedraw = () => { scBodyBuild(SCAN.rec.extr); scanDraw(); scPanel(); };",
    "const scBodyRedraw = () => { scBodyBuild(SCAN.rec.extr); if (SCAN.reconGroup && SCAN.reconGroup.parent && SCAN.tool === 'recognise') scBodyDraw(SCAN.reconGroup, SCAN.rec, SCAN.view); else scanDraw(); scPanel(); c9Fill(); };", what='redraw: light')

# 3. the pick: many with Shift; a right click opens the section
rep("const S = SCAN.sel; if ((!sel && !S) || (sel && S && sel.type === S.type && sel.i === S.i)) return; SCAN.sel = sel; if (sel && SCAN.tab !== 'quant') SCAN.tab = 'edit'; scBodyRedraw();\n}",
    "c9Pick(sel, ev);\n}", what='pick')
rep("<= 4) scBodyPick(e); return; }",
    "<= 4) scBodyPick(e); else if (dn && e.button === 2 && Math.hypot(e.clientX - dn.x, e.clientY - dn.y) <= 4) c9Open(e); return; }", what='right click')
rep("if (S.type === 'face') scBodyDelete(S.i); else scBodyMerge(S.i); } if (e.key === 'Escape') { SCAN.sel = null; scBodyRedraw(); } });",
    "c9DeletePicked(); } if (e.key === 'Escape') { SCAN.sel = null; c9Close(true); scBodyRedraw(); } });", what='keys')

# 4. every frame: the manipulator and the boxes
rep("controls.update(); gzUpdate(); sun.position.copy(camera.position);", "controls.update(); gzUpdate(); c9Frame(); sun.position.copy(camera.position);", what='frame')

# 5. Quantise: what lands on its grid is marked as held to it; the step of sizes is 1 mm; many picked faces
rep("{ aStep: 5, aWithin: 2, sStep: 0.5 }", "{ aStep: 5, aWithin: 2, sStep: 1 }", s.count("{ aStep: 5, aWithin: 2, sStep: 0.5 }"), 'quant: 1 mm')
for t in ("scUser('angles quantised', {", "scUser('sizes quantised', {", "scUser('faces set along the axes', {"):
    rep(t, "c9AfterQuant(); " + t, what='quant: flags')
rep("pickedFace = body && SCAN.sel && SCAN.sel.type === 'face' && SCAN.rec.extr.ents[SCAN.sel.i] && SCAN.rec.extr.ents[SCAN.sel.i].t === 'line' ? SCAN.sel.i : null;", "pickedFace = body ? c9PickedFlat() : null;", what='quant: picked')
rep("(one && X.ents.indexOf(e) !== only)", "(one && ![].concat(only).includes(X.ents.indexOf(e)))", what='quant: many')
rep("'A face is picked: the buttons act on it alone.'", "'Faces are picked: the buttons act on them alone.'", what='quant: text')

# 6. File: the experience; the project keeps the measured profile and the flags
rep("btn('Save project', () => scSaveAs('project'), rec) + cap('Export')",
    "btn('Save project', () => scSaveAs('project'), rec) + cap('Experience') + btn('Save the experience file', c9ExpSave, rec) + btn('Add an experience file…', c9ExpLoad) + cap('Export')", what='file: experience')
rep("user: e.user || null })) } : null,",
    "user: e.user || null, id: e.id || null, sizeHeldTo: e.ql || null, angleAfterItHeldTo: e.qa || null })), measuredProfile: X.meas || null } : null,", what='project')

# 7. the words under "The body"
rep("Delete removes what is picked; Undo is at the top (Ctrl+Z).</div>",
    "Shift adds to the pick; a click on a picked one lets it go. A right click on an edge opens its section with the manipulator. Lines: blue a flat face, violet a round one, strong when its size is held to the grid, pale when free; red is doubtful. Corners: a square is held, a circle is free. Delete removes what is picked; Undo is at the top (Ctrl+Z).</div>", what='words')

# 7b. Redo beside Undo: what Undo takes away is kept; a new change of the body lets it go
rep("if (SCAN.undo.length > 100) SCAN.undo.shift(); scUndoBtn(); };", "if (SCAN.undo.length > 100) SCAN.undo.shift(); if (!SCAN.redoing) SCAN.redo = []; scUndoBtn(); };", what='redo: keep')
rep("const o = JSON.parse(SCAN.undo.pop()); X.ents = o.ents; X.t0 = o.t0;", "(SCAN.redo = SCAN.redo || []).push(c9Now(X)); const o = JSON.parse(SCAN.undo.pop()); X.ents = o.ents; X.t0 = o.t0;", what='redo: undo feeds it')
rep("b.textContent = n ? `↶ Undo (${n})` : '↶ Undo'; }", "b.textContent = n ? `↶ Undo (${n})` : '↶ Undo'; c9RedoBtn(b); }", what='redo: button')
rep("if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); scUndo(); return; }", "if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? scRedo() : scUndo(); return; } if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); scRedo(); return; }", what='redo: keys')

rep("btn(`↶ Undo${SCAN.undo && SCAN.undo.length ? ' (' + SCAN.undo.length + ')' : ''}`, scUndo, !!(SCAN.undo && SCAN.undo.length))",
    "btn(`↶ Undo${SCAN.undo && SCAN.undo.length ? ' (' + SCAN.undo.length + ')' : ''}`, scUndo, !!(SCAN.undo && SCAN.undo.length)) + btn(`↷ Redo${SCAN.redo && SCAN.redo.length ? ' (' + SCAN.redo.length + ')' : ''}`, scRedo, !!(SCAN.redo && SCAN.redo.length))", what='redo: left panel')

# 7c. an edge of a face at an end of the body can be picked (right click); a click reaches the larger marks of the corners
rep("return [r.left + (v.x + 1) / 2 * r.width, r.top + (1 - v.y) / 2 * r.height]; }; let best = null, bd = 7;", "return [r.left + (v.x + 1) / 2 * r.width, r.top + (1 - v.y) / 2 * r.height]; }; let best = null, bd = 10;", what='pick: reach')
rep("+ (S && S.type === 'edge' ? box('#e0b000',", "+ c9RimHtml(X, S, box) + (S && S.type === 'edge' ? box('#e0b000',", what='panel: rim')
rep("Shift adds to the pick; a click on a picked one lets it go. A right click on an edge opens its section with the manipulator.",
    "Shift adds to the pick; a click on a picked one lets it go. A right click on an edge along the body opens its section with the manipulator; a right click on an edge of a face at an end of the body picks that edge.", what='words: rim')

# 7d. the small yellow squares 08 put on the ends of a picked edge are not drawn: the marks of the corners turn yellow themselves
rep("X.selPos.length) { const pg = new THREE.BufferGeometry();", "X.selPos.length && !c9Vertices) { const pg = new THREE.BufferGeometry();", what='draw: old marks of a picked edge off')

# 8. the module itself
rep("window.__scan = SCAN; window.__scanFn = {", js + "\nwindow.__scan = SCAN; window.__scanFn = {", what='module')

open(out, 'w', encoding='utf-8').write(s)
print(f'{out}: {len(s):,} bytes, {len(done)} changes')
